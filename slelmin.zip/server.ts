/**
 * Full-stack Express server for Loupe
 * Handles server-side Gemini API calls securely without exposing keys to the browser
 */
import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import {
  directAiAnalyze,
  directAiLocate,
  directAiZoomRegion,
  directAiGlobal,
  directAiExtract,
  initModelRegistry,
  getAvailableModels,
} from './src/services/ai';

dotenv.config({ override: true });

const app = express();
const PORT = 3000;

// High limit for base64 screenshots
app.use(express.json({ limit: '50mb' }));

// Health endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    app: 'Loupe',
    version: '2.1.0',
    hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
    availableModels: Array.from(getAvailableModels()),
  });
});

// Server-side AI Analyze endpoint
app.post('/api/ai/analyze', async (req, res) => {
  try {
    const { images } = req.body;
    if (!images || !Array.isArray(images) || images.length === 0) {
      return res.status(400).json({ code: 'network', message: 'No images provided' });
    }

    const result = await directAiAnalyze(images);
    return res.json(result);
  } catch (err: any) {
    console.error('AI analyze error:', err);
    const upstreamStatus = Number(err?.status || err?.statusCode || 500);
    const status = Number.isInteger(upstreamStatus) && upstreamStatus >= 400 && upstreamStatus < 600 ? upstreamStatus : 500;
    return res.status(status).json({
      code: err?.code || 'ai_error',
      message: err?.message || String(err),
      status,
      rawError: err?.stack || err?.message || String(err),
    });
  }
});

// Server-side AI Extract endpoint
app.post('/api/ai/extract', async (req, res) => {
  try {
    const { images, measurements } = req.body;
    if (!images || !Array.isArray(images) || images.length === 0) {
      return res.status(400).json({ code: 'network', message: 'No images provided' });
    }

    const spec = await directAiExtract(images, measurements || { palette: [], dimensions: [] });
    return res.json(spec);
  } catch (err: any) {
    console.error('AI extract error:', err);
    const upstreamStatus = Number(err?.status || err?.statusCode || 500);
    const status = Number.isInteger(upstreamStatus) && upstreamStatus >= 400 && upstreamStatus < 600 ? upstreamStatus : 500;
    return res.status(status).json({
      code: err?.code || 'ai_error',
      message: err?.message || String(err),
      status,
    });
  }
});

// Server-side AI Locate endpoint (Pass A)
app.post('/api/ai/locate', async (req, res) => {
  try {
    const { images } = req.body;
    if (!images || !Array.isArray(images) || images.length === 0) {
      return res.status(400).json({ code: 'network', message: 'No images provided' });
    }

    const elements = await directAiLocate(images);
    return res.json(elements);
  } catch (err: any) {
    console.error('AI locate error:', err);
    const upstreamStatus = Number(err?.status || err?.statusCode || 500);
    const status = Number.isInteger(upstreamStatus) && upstreamStatus >= 400 && upstreamStatus < 600 ? upstreamStatus : 500;
    return res.status(status).json({
      code: err?.code || 'ai_error',
      message: err?.message || String(err),
      status,
    });
  }
});

// Server-side AI Zoom Region endpoint (Pass B)
app.post('/api/ai/zoom', async (req, res) => {
  try {
    const { imageBase64, measurements } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ code: 'network', message: 'No image provided' });
    }

    const details = await directAiZoomRegion(imageBase64, measurements);
    return res.json(details);
  } catch (err: any) {
    console.error('AI zoom error:', err);
    const upstreamStatus = Number(err?.status || err?.statusCode || 500);
    const status = Number.isInteger(upstreamStatus) && upstreamStatus >= 400 && upstreamStatus < 600 ? upstreamStatus : 500;
    return res.status(status).json({
      code: err?.code || 'ai_error',
      message: err?.message || String(err),
      status,
    });
  }
});

// Server-side AI Global endpoint (Pass C)
app.post('/api/ai/global', async (req, res) => {
  try {
    const { image1024Base64 } = req.body;
    if (!image1024Base64) {
      return res.status(400).json({ code: 'network', message: 'No image provided' });
    }

    const globalDetails = await directAiGlobal(image1024Base64);
    return res.json(globalDetails);
  } catch (err: any) {
    console.error('AI global error:', err);
    const upstreamStatus = Number(err?.status || err?.statusCode || 500);
    const status = Number.isInteger(upstreamStatus) && upstreamStatus >= 400 && upstreamStatus < 600 ? upstreamStatus : 500;
    return res.status(status).json({
      code: err?.code || 'ai_error',
      message: err?.message || String(err),
      status,
    });
  }
});

// Mount Vite or serve static
async function startServer() {
  // Initialize model registry on server startup (T0)
  try {
    await initModelRegistry();
  } catch (e) {
    console.warn('Model registry init warning:', e);
  }

  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve('dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve('dist/index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Loupe server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
