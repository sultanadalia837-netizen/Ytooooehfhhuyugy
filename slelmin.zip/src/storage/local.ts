/**
 * IndexedDB adapter using idb-keyval
 * Document 2, Section 5.7
 */
import { createStore, get, set, del, values } from 'idb-keyval';
import { Result, SiteGroup } from '../types';
import { HISTORY_MAX } from '../config';

// Dedicated custom stores within the "loupe" IndexedDB database
const resultsStore = typeof window !== 'undefined' ? createStore('loupe-db', 'results') : null as any;
const cacheStore = typeof window !== 'undefined' ? createStore('loupe-db', 'cache') : null as any;
const metaStore = typeof window !== 'undefined' ? createStore('loupe-db', 'meta') : null as any;
const passCacheStore = typeof window !== 'undefined' ? createStore('loupe-db', 'pass_cache') : null as any;

// In-memory fallbacks for non-browser or disabled IndexedDB
const memResults = new Map<string, Result>();
const memCache = new Map<string, string>();
const memMeta = new Map<string, any>();
const memPassCache = new Map<string, any>();

export async function saveResult(result: Result): Promise<void> {
  try {
    if (resultsStore) {
      await set(result.id, result, resultsStore);
      if (result.cacheKey) {
        await set(result.cacheKey, result.id, cacheStore);
      }
      // Check HISTORY_MAX limit and prune oldest
      const all = await listResults();
      if (all.length > HISTORY_MAX) {
        const sorted = all.sort((a, b) => b.createdAt - a.createdAt);
        const toDelete = sorted.slice(HISTORY_MAX);
        for (const item of toDelete) {
          await deleteResult(item.id);
        }
      }
      return;
    }
  } catch (e) {
    console.warn('IndexedDB write failed, using memory store:', e);
  }
  memResults.set(result.id, result);
  if (result.cacheKey) memCache.set(result.cacheKey, result.id);
}

export async function getResult(id: string): Promise<Result | undefined> {
  try {
    if (resultsStore) {
      const res = await get<Result>(id, resultsStore);
      if (res) return res;
    }
  } catch (e) {
    console.warn('IndexedDB read failed:', e);
  }
  return memResults.get(id);
}

export async function listResults(): Promise<Result[]> {
  try {
    if (resultsStore) {
      const all = await values<Result>(resultsStore);
      return all.sort((a, b) => b.createdAt - a.createdAt);
    }
  } catch (e) {
    console.warn('IndexedDB list failed:', e);
  }
  return Array.from(memResults.values()).sort((a, b) => b.createdAt - a.createdAt);
}

export async function deleteResult(id: string): Promise<void> {
  try {
    if (resultsStore) {
      const item = await get<Result>(id, resultsStore);
      if (item?.cacheKey) {
        await del(item.cacheKey, cacheStore);
      }
      await del(id, resultsStore);
      return;
    }
  } catch (e) {
    console.warn('IndexedDB delete failed:', e);
  }
  const item = memResults.get(id);
  if (item?.cacheKey) memCache.delete(item.cacheKey);
  memResults.delete(id);
}

export async function getCachedResultId(cacheKey: string): Promise<string | undefined> {
  try {
    if (cacheStore) {
      const id = await get<string>(cacheKey, cacheStore);
      if (id) return id;
    }
  } catch (e) {
    console.warn('Cache lookup failed:', e);
  }
  return memCache.get(cacheKey);
}

export async function setCache(cacheKey: string, resultId: string): Promise<void> {
  try {
    if (cacheStore) {
      await set(cacheKey, resultId, cacheStore);
      return;
    }
  } catch (e) {
    console.warn('Set cache failed:', e);
  }
  memCache.set(cacheKey, resultId);
}

export async function getSiteQueue(): Promise<SiteGroup[]> {
  try {
    if (metaStore) {
      const queue = await get<SiteGroup[]>('siteQueue', metaStore);
      return queue || [];
    }
  } catch (e) {
    console.warn('getSiteQueue failed:', e);
  }
  return memMeta.get('siteQueue') || [];
}

export async function setSiteQueue(queue: SiteGroup[]): Promise<void> {
  try {
    if (metaStore) {
      await set('siteQueue', queue, metaStore);
      return;
    }
  } catch (e) {
    console.warn('setSiteQueue failed:', e);
  }
  memMeta.set('siteQueue', queue);
}

export async function getDeviceId(): Promise<string> {
  try {
    if (metaStore) {
      let id = await get<string>('deviceId', metaStore);
      if (!id) {
        id = `dev_${Math.random().toString(36).substring(2, 12)}`;
        await set('deviceId', id, metaStore);
      }
      return id;
    }
  } catch (e) {
    console.warn('getDeviceId failed:', e);
  }
  let id = memMeta.get('deviceId');
  if (!id) {
    id = `dev_${Math.random().toString(36).substring(2, 12)}`;
    memMeta.set('deviceId', id);
  }
  return id;
}

export async function getPassCache<T>(key: string): Promise<T | undefined> {
  try {
    if (passCacheStore) {
      const res = await get<T>(key, passCacheStore);
      if (res !== undefined) return res;
    }
  } catch (e) {
    console.warn('Pass cache lookup failed:', e);
  }
  return memPassCache.get(key);
}

export async function setPassCache<T>(key: string, data: T): Promise<void> {
  try {
    if (passCacheStore) {
      await set(key, data, passCacheStore);
      return;
    }
  } catch (e) {
    console.warn('Set pass cache failed:', e);
  }
  memPassCache.set(key, data);
}
