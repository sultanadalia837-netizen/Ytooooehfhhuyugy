/**
 * Configuration and constants for Loupe v2.0.0
 * Document 2, Section 5.3 & Visual Reproduction Spec
 */

export const APP_NAME = 'Loupe';
export const TAGLINE = 'See the design. Rebuild it exactly.';
export const PIPELINE_VERSION = '2.1.0';

// Gemini model configurations
// Detail tier (Pass A locate, Pass B regions):
export const GEMINI_DETAIL_PRIMARY = (typeof process !== 'undefined' && process.env?.GEMINI_DETAIL_PRIMARY) || 'gemini-3.5-flash';
export const GEMINI_DETAIL_FALLBACK = (typeof process !== 'undefined' && process.env?.GEMINI_DETAIL_FALLBACK) || 'gemini-3.6-flash';
export const GEMINI_DETAIL_MODELS = [GEMINI_DETAIL_PRIMARY, GEMINI_DETAIL_FALLBACK];

// Lite tier (Pass C global, or emergency detail fallback):
export const GEMINI_LITE_PRIMARY = (typeof process !== 'undefined' && process.env?.GEMINI_LITE_PRIMARY) || 'gemini-3.5-flash-lite';
export const GEMINI_LITE_FALLBACK = (typeof process !== 'undefined' && process.env?.GEMINI_LITE_FALLBACK) || 'gemini-flash-lite-latest';
export const GEMINI_LITE_MODELS = [GEMINI_LITE_PRIMARY, GEMINI_LITE_FALLBACK];

// Backward-compatible aliases
export const GEMINI_MODEL = GEMINI_DETAIL_PRIMARY;
export const GEMINI_ANALYZE_MODEL = GEMINI_LITE_PRIMARY;
export const GEMINI_LOCATE_MODEL = GEMINI_DETAIL_PRIMARY;
export const GEMINI_FALLBACK_MODELS = [GEMINI_DETAIL_FALLBACK, GEMINI_LITE_PRIMARY];

// Concurrency and rate limiting
export const GLOBAL_CONCURRENCY = 2;
export const MIN_REQUEST_GAP_MS = 250;

// Timeout and budget policies
export const CALL_TIMEOUT_MS = 60000; // 60s hard timeout per server call
export const CLIENT_CALL_TIMEOUT_MS = 70000; // server timeout + 10s
export const TOTAL_EXTRACTION_BUDGET_MS = 120000; // 120s total extraction budget
export const REGION_DEADLINE_MS = 100000; // stop launching new region calls after 100s
export const MAX_RETRY_DELAY_MS = 20000; // cap 429 retry delay at 20s

// Generation token caps
export const LOCATE_MAX_OUTPUT_TOKENS = 2048;
export const REGION_MAX_OUTPUT_TOKENS = 3000;
export const GLOBAL_MAX_OUTPUT_TOKENS = 3000;
export const ANALYZE_MAX_OUTPUT_TOKENS = 2048;

export const GEN_CONFIG = {
  maxOutputTokens: 3000,
  thinkingConfig: {
    thinkingLevel: 'LOW' as const,
  },
};

export const EXTRACT_GEN_CONFIG = {
  maxOutputTokens: 3000,
  thinkingConfig: {
    thinkingLevel: 'LOW' as const,
  },
};

export const MAX_FILES = 8;
export const MAX_FILE_MB = 10;
export const MIN_WIDTH = 200;
export const MIN_HEIGHT = 150;
export const MAX_DIM = 12000;
export const BLUR_THRESHOLD = 0.5;
export const MAX_SEGMENTS = 8;
export const SEGMENT_RATIO = 1.25;
export const TALL_RATIO = 2.2;
export const AI_MAX_SIDE = 1600;
export const AI_JPEG_QUALITY = 0.92;
export const COLOR_SNAP_DISTANCE = 40;
export const COLOR_MERGE_DISTANCE = 24;
export const HISTORY_MAX = 50;
export const SHARE_IMAGE_MAX_BYTES = 600000;
export const COVER_WIDTH = 480;
export const COVER_MAX_BYTES = 50000;
export const LIBRARY_FIRST_PAGE = 48;
export const LIBRARY_PAGE = 24;
export const AUTH_ENABLED = false;
export const PAYMENTS_ENABLED = false;

// Standard controlled vocabularies for tagging
export const INDUSTRY_TAGS = [
  'ai-tech',
  'saas',
  'fintech',
  'agency',
  'e-commerce',
  'developer-tools',
  'portfolio',
  'crypto-web3',
  'health-wellness',
  'media-editorial',
] as const;

export const STYLE_TAGS = [
  'dark',
  'light',
  'minimal',
  'enterprise',
  'retro-cyber',
  'playful',
  'monochrome',
  'brutalist',
  'high-contrast',
] as const;

export const SECTION_TAGS = [
  'hero',
  'pricing',
  'features',
  'faq',
  'testimonials',
  'navigation',
  'footer',
  'cta',
  'dashboard',
  'form',
] as const;

export const ANALYZE_PROMPT = `You are Loupe's screenshot inspection engine.
Analyze the provided website or application interface screenshot(s) carefully.

TASK:
1. Verify if the provided images are legitimate screenshots of a website, web application, dashboard, landing page, mobile web view, UI component, or digital interface design.
   - Set isWebsite to true for ANY digital website, web app, dashboard, mobile UI, or design mockup.
   - ONLY set isWebsite to false if the image is NOT a digital user interface at all or contains adult/unsafe material.
2. Determine if the screenshots belong to ONE website or MULTIPLE different websites.
3. Group the screenshots by website:
   - id: unique slug (e.g. "site-1")
   - label: concise descriptive label in format "<Brand>: <Type>" (if unknown, "unknown: <Type>")
   - description: 1 short sentence
   - sections: array of detected section types (e.g. ["hero", "features"])
   - imageIndices: array of 0-based indices

Return ONLY valid JSON:
{
  "isWebsite": boolean,
  "rejectionCode": string | null,
  "rejectionReason": string | null,
  "sites": [
    {
      "id": string,
      "label": string,
      "description": string,
      "sections": string[],
      "imageIndices": number[]
    }
  ]
}`;

// Pass A Prompt (<= 1.5k chars)
export const LOCATE_PROMPT = `You are Loupe's element locator. Detect all visible and layout-indicated UI elements (up to 40) in this cropped interface screenshot.
If the image is a solid color, blank canvas, or lacks distinct UI elements/cards/buttons/text, return {"elements": []}.
Detect and separate every UI element:
- Top nav links: Home, About, Careers, Pricing, Login, Contact, and Get Started CTA
- Center hero headline: 'Build Your Identity, Connect Your World'
- Author/cursor tags: Robert, Clarissa
- Bottom card containers: Cloudy, Dummies, Glue, Groove mumies, Ellenor
- Floating props and icons: geometric shapes, circles, squares
For each element, specify:
- id: short identifier (e.g. "el-1")
- kind: one of ["card", "button", "nav", "text", "badge", "icon", "image", "character", "prop", "input", "container", "other"]
- label: descriptive name
- box_2d: normalized bounding box [ymin, xmin, ymax, xmax] strictly from 0 to 1000
- text: verbatim visible or indicated text, or null if no text

RULES:
1. No fabricated elements on blank canvases. "unknown" over guessing.
2. Every nav link, button, card title, and cursor tag must be a separate element.
3. Output valid JSON only:
{"elements": [{"id": "el-1", "kind": "nav", "label": "Nav Home", "box_2d": [20, 100, 50, 150], "text": "Home"}]}`;

// Pass B Prompt (<= 1.5k chars)
export const REGION_PROMPT = `You are Loupe's high-magnification regional inspector. Inspect this cropped screenshot region and its measured colors.
If the region is blank or a solid color, return empty arrays.
Extract:
- texts: array of exact visible or layout-indicated strings (verbatim casing). Include every card name (Cloudy, Dummies, Glue, Groove mumies, Ellenor), button (Get Started), nav item (Home, About, Careers, Pricing, Login, Contact), cursor tag (Robert, Clarissa), title, subtitle.
- typography: array of text styles { sampleText, size, weight, spacing, fontCharacteristics }
- cards: array of card containers { label, radius, gradientStops, shadow, rotation, crop, box_2d }
- characters: array of characters/mascots { label, description (<= 40 words: who/what it is, clothing, held items, colors, pose), crop, box_2d }
- props: array of 3D objects/props { label, description (<= 40 words: what it is, geometry, colors, materials, lighting), crop, box_2d }
- icons: array of icons { name, description, box_2d }

RULES:
1. "unknown" over guessing.
2. Verbatim text.
3. Max 40 words per character/prop description.
4. Output valid JSON only:
{"texts": [], "typography": [], "cards": [], "characters": [], "props": [], "icons": []}`;

// Pass C Prompt (<= 1.5k chars)
export const GLOBAL_PROMPT = `You are Loupe's design system architect. Inspect this interface screenshot and extract the global design foundation:
- theme: "dark" | "light" | "mixed"
- title: brand or product name (or "unknown")
- summary: 1-2 sentence high-level visual summary
- description: 2-3 sentence architectural description of the visual system
- fontPairing: { primary: string, substitute: string, secondary?: string }
- radii: array of { element: string, value: string } (e.g. cards, buttons, badges)
- shadows: array of { name: string, value: string }
- spacing: { baseUnit: number, density: "compact"|"comfortable"|"spacious", pageMaxWidth: string }
- dosAndDonts: { dos: string[], donts: string[] }

RULES:
1. No example copying.
2. "unknown" over guessing.
3. Output valid JSON only:
{"theme": "dark", "title": "unknown", "summary": "", "description": "", "fontPairing": {"primary": "unknown", "substitute": "unknown"}, "radii": [], "shadows": [], "spacing": {"baseUnit": 8, "density": "comfortable", "pageMaxWidth": "1440px"}, "dosAndDonts": {"dos": [], "donts": []}}`;
