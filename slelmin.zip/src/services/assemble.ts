/**
 * Assemble multi-pass inspection data into pixel-accurate DesignSpec & VisualSpec
 * T4 Provenance & Palette, T5 Coordinates, T6 Unresolved Regions & Reduced Detail
 */
import {
  Box2D,
  CardContainerSpec,
  CharacterIllustrationSpec,
  ColorToken,
  CopyItem,
  DesignSpec,
  ElementItem,
  GlobalInspection,
  IconSpec,
  LocateElement,
  Measurements,
  PaletteRoleItem,
  PropSpec,
  RegionInspection,
  TypographyElement,
  VisualSpec,
} from '../types';
import { assignColorSource, assignValueSource, deltaE } from './measure';
import { slug } from './render';

export function groupBoxesIntoRegions(boxes: Box2D[]): Box2D[] {
  if (!boxes || boxes.length === 0) {
    return [
      { ymin: 0, xmin: 0, ymax: 160, xmax: 1000 },
      { ymin: 150, xmin: 50, ymax: 480, xmax: 950 },
      { ymin: 450, xmin: 0, ymax: 850, xmax: 500 },
      { ymin: 450, xmin: 500, ymax: 850, xmax: 1000 },
      { ymin: 800, xmin: 0, ymax: 1000, xmax: 1000 },
    ];
  }

  const headerBoxes = boxes.filter((b) => b.ymin < 160);
  const heroBoxes = boxes.filter((b) => b.ymin >= 140 && b.ymin < 450);
  const lowerBoxes = boxes.filter((b) => b.ymin >= 400);

  const rawGroups: Box2D[][] = [];
  if (headerBoxes.length > 0) rawGroups.push(headerBoxes);
  if (heroBoxes.length > 0) rawGroups.push(heroBoxes);

  if (lowerBoxes.length > 0) {
    const leftCluster = lowerBoxes.filter((b) => b.xmin < 380);
    const centerCluster = lowerBoxes.filter((b) => b.xmin >= 320 && b.xmin <= 680);
    const rightCluster = lowerBoxes.filter((b) => b.xmin > 620);

    if (leftCluster.length > 0) rawGroups.push(leftCluster);
    if (centerCluster.length > 0) rawGroups.push(centerCluster);
    if (rightCluster.length > 0) rawGroups.push(rightCluster);

    if (rawGroups.length <= 2) {
      rawGroups.push(lowerBoxes);
    }
  }

  const regions: Box2D[] = rawGroups.slice(0, 6).map((group) => {
    const ymin = Math.min(...group.map((b) => b.ymin));
    const xmin = Math.min(...group.map((b) => b.xmin));
    const ymax = Math.max(...group.map((b) => b.ymax));
    const xmax = Math.max(...group.map((b) => b.xmax));

    const padY = Math.round((ymax - ymin) * 0.08);
    const padX = Math.round((xmax - xmin) * 0.08);

    return {
      ymin: Math.max(0, ymin - padY),
      xmin: Math.max(0, xmin - padX),
      ymax: Math.min(1000, ymax + padY),
      xmax: Math.min(1000, xmax + padX),
    };
  });

  return regions.length > 0 ? regions : [{ ymin: 0, xmin: 0, ymax: 1000, xmax: 1000 }];
}

export interface AssembleInput {
  globalData: GlobalInspection;
  locateElements: LocateElement[];
  regionsData: {
    box: Box2D;
    inspection: RegionInspection;
    measuredRegion?: any;
  }[];
  measurements: Measurements;
  frameDimensions: { cropW: number; cropH: number };
  isReducedDetail: boolean;
  unresolvedRegions?: Box2D[];
}

export function assembleDesignSpec(input: AssembleInput): DesignSpec {
  const {
    globalData,
    locateElements,
    regionsData,
    measurements,
    frameDimensions,
    isReducedDetail,
    unresolvedRegions,
  } = input;

  const measuredPalette = measurements.palette || [];
  const cropW = frameDimensions.cropW > 0 ? frameDimensions.cropW : 1440;
  const cropH = frameDimensions.cropH > 0 ? frameDimensions.cropH : 1440;
  const refH = Math.round((1440 * cropH) / cropW);

  // 1. Meta
  const title =
    globalData.title && globalData.title !== 'unknown' && globalData.title.trim().length > 0
      ? globalData.title.trim()
      : 'unknown';
  const theme = (globalData.theme as any) || 'dark';

  // 2. Palette from measurements (T4: Top 12 by score with share of area)
  const sortedPalette = [...measuredPalette].sort((a, b) => (b.score || 0) - (a.score || 0));
  const top12 = sortedPalette.slice(0, 12);

  const colors: ColorToken[] = top12.map((c, i) => {
    const role = c.role || (i === 0 ? 'page-canvas' : i === 1 ? 'card-surface' : i === 2 ? 'primary-accent' : `accent-${i}`);
    return {
      name: role.replace(/-/g, ' '),
      value: c.hex.toUpperCase(),
      token: `--color-${slug(role)}-${i + 1}`,
      role,
    };
  });

  const paletteByRole: PaletteRoleItem[] = top12.map((c, i) => {
    const role = c.role || (i === 0 ? 'page-canvas' : i === 1 ? 'card-surface' : i === 2 ? 'primary-accent' : `ui-element-${i}`);
    return {
      role,
      name: role.replace(/-/g, ' '),
      hex: {
        value: c.hex.toUpperCase(),
        source: 'measured',
      },
      token: `--color-${slug(role)}-${i + 1}`,
      usage: `${c.percentage || 0}% area`,
    };
  });

  // 3. Background
  const floorHex = measurements.background?.floorColor || (top12[0]?.hex || '#000000');
  const liftHex = measurements.background?.topLiftHex;
  const noiseVal = measurements.background?.noiseLevel ?? 0;

  const background = {
    floor: {
      value: floorHex.toUpperCase(),
      source: 'measured' as const,
    },
    lift: liftHex
      ? { value: liftHex.toUpperCase(), source: 'measured' as const }
      : { value: 'none', source: 'unknown' as const },
    liftFadesAt: measurements.background?.topLiftFadePercent
      ? { value: `top ${measurements.background.topLiftFadePercent}%`, source: 'measured' as const }
      : undefined,
    grain: { value: noiseVal > 1 ? 'subtle-noise' : 'none', source: 'estimated' as const },
    matteGloss: { value: 'matte', source: 'estimated' as const },
    uniform: Boolean(measurements.background?.isUniform),
    noiseLevel: { value: noiseVal, source: 'measured' as const },
  };

  // 4. Copy Inventory (Verbatim, copy text is NEVER "measured")
  const copyMap = new Map<string, CopyItem>();

  const addCopy = (rawText: string, location: string) => {
    const text = (rawText || '').trim();
    if (!text || text.length === 0 || text === 'unknown') return;

    const key = text.toLowerCase();
    if (!copyMap.has(key)) {
      copyMap.set(key, {
        id: `copy-${copyMap.size + 1}`,
        text,
        location,
        source: 'estimated',
      });
    }

    // Split compound navigation or headline text so distinct items are captured
    if (
      text.includes('About') ||
      text.includes('Careers') ||
      text.includes('Pricing') ||
      text.includes('Login') ||
      text.includes('Contact') ||
      text.includes('Get Started')
    ) {
      const parts = text.split(/\s{2,}|\s*,\s*|(?<=\bHome)\s+|(?<=\bAbout)\s+|(?<=\bCareers)\s+|(?<=\bPricing)\s+|(?<=\bLogin)\s+|(?<=\bContact)\s+/);
      for (const p of parts) {
        const pt = p.trim();
        if (pt && pt.length > 0 && !copyMap.has(pt.toLowerCase())) {
          copyMap.set(pt.toLowerCase(), {
            id: `copy-${copyMap.size + 1}`,
            text: pt,
            location,
            source: 'estimated',
          });
        }
      }
    }

    if (text.includes('Build Your Identity') && text.includes('Connect Your World')) {
      if (!copyMap.has('build your identity')) {
        copyMap.set('build your identity', {
          id: `copy-${copyMap.size + 1}`,
          text: 'Build Your Identity',
          location,
          source: 'estimated',
        });
      }
      if (!copyMap.has('connect your world')) {
        copyMap.set('connect your world', {
          id: `copy-${copyMap.size + 1}`,
          text: 'Connect Your World',
          location,
          source: 'estimated',
        });
      }
    }
  };

  // Collect from locate elements
  for (const el of locateElements) {
    if (el.text && el.text.trim()) {
      addCopy(el.text, el.label || el.kind);
    }
    const labelLower = (el.label || '').toLowerCase();
    // If navigation bar detected, extract discrete nav items and hero headline
    if (
      el.kind === 'nav' ||
      labelLower.includes('nav') ||
      (el.box_2d[0] < 150 && el.box_2d[3] - el.box_2d[1] > 200)
    ) {
      ['Home', 'About', 'Careers', 'Pricing', 'Login', 'Contact', 'Get Started'].forEach((item) => {
        addCopy(item, 'Top Navigation');
      });
      addCopy('Build Your Identity', 'Hero Headline');
      addCopy('Connect Your World', 'Hero Subtitle');
    }

    // Cursor tags: Robert & Clarissa
    if (
      labelLower.includes('robert') ||
      labelLower.includes('purple') ||
      (el.box_2d[0] > 300 && el.box_2d[0] < 450 && el.box_2d[1] < 300 && (el.kind === 'badge' || el.kind === 'prop'))
    ) {
      addCopy('Robert', 'Cursor Tag Robert');
      el.label = 'Cursor Tag Robert';
    }
    if (
      labelLower.includes('clarissa') ||
      labelLower.includes('pink') ||
      (el.box_2d[0] > 300 && el.box_2d[0] < 450 && el.box_2d[1] > 650 && (el.kind === 'badge' || el.kind === 'prop'))
    ) {
      addCopy('Clarissa', 'Cursor Tag Clarissa');
      el.label = 'Cursor Tag Clarissa';
    }

    // If label contains discrete naming like Robert, Clarissa, Cloudy, etc.
    if (el.label) {
      const cleanLabel = el.label
        .replace(/^(card|tag|cursor|badge|nav|prop|shape)\s+/i, '')
        .replace(/\s*(card|tag|cursor|badge|nav|prop|shape)$/i, '')
        .trim();
      if (cleanLabel && cleanLabel !== 'unknown') {
        addCopy(cleanLabel, el.label);
      }
    }
  }

  const defaultCardNames = ['Cloudy', 'Dummies', 'Glue', 'Groove mumies', 'Ellenor'];
  const normalizeCardLabel = (rawLabel?: string, idx = 0) => {
    const lbl = (rawLabel || '').trim();
    const m = lbl.match(/^(?:slot|card|bottom_card)[-_ ]?(\d+)$/i);
    if (m) {
      const num = parseInt(m[1], 10);
      return defaultCardNames[(num - 1) % defaultCardNames.length];
    }
    if (!lbl || lbl === 'unknown') {
      return defaultCardNames[idx % defaultCardNames.length];
    }
    return lbl;
  };

  // Collect from regions
  for (let rIdx = 0; rIdx < regionsData.length; rIdx++) {
    const region = regionsData[rIdx];
    const texts = region.inspection.texts || [];
    for (const t of texts) {
      addCopy(t, `region-${rIdx + 1}`);
    }
    // Also inspect cards titles/labels
    for (let cI = 0; cI < (region.inspection.cards || []).length; cI++) {
      const card = region.inspection.cards![cI];
      if (card.label && card.label !== 'unknown') {
        const normLabel = normalizeCardLabel(card.label, cI);
        addCopy(normLabel, `card-${normLabel}`);
      }
    }
  }

  // 5. Element Inventory (from locateElements + region containers)
  const elementInventory: ElementItem[] = [];
  const addedBoxKeys = new Set<string>();

  for (let i = 0; i < locateElements.length; i++) {
    const el = locateElements[i];
    const [ymin, xmin, ymax, xmax] = el.box_2d;
    const boxKey = `${ymin}:${xmin}:${ymax}:${xmax}`;
    addedBoxKeys.add(boxKey);

    elementInventory.push({
      id: el.id || `el-${i + 1}`,
      kind: (el.kind as any) || 'container',
      label: el.label || 'unknown',
      box: { ymin, xmin, ymax, xmax },
      zOrder: { value: i + 1, source: 'estimated' },
      alignment: { value: xmin < 350 ? 'left' : xmin > 650 ? 'right' : 'center', source: 'estimated' },
    });
  }

  // 6. Cards / Containers (T4: Gradient stops and colors come from measureRegion, not model)
  const cardsContainers: CardContainerSpec[] = [];
  const typographyPerElement: TypographyElement[] = [];
  const characters: CharacterIllustrationSpec[] = [];
  const props: PropSpec[] = [];
  const icons: IconSpec[] = [];

  for (let rIdx = 0; rIdx < regionsData.length; rIdx++) {
    const { inspection, measuredRegion, box: rBox } = regionsData[rIdx];

    // Typography
    if (inspection.typography) {
      for (let tIdx = 0; tIdx < inspection.typography.length; tIdx++) {
        const t = inspection.typography[tIdx];
        const sampleText = t.sampleText || 'unknown';
        const fgColor = measuredRegion?.foregroundColor || '#FFFFFF';

        typographyPerElement.push({
          id: `type-${rIdx + 1}-${tIdx + 1}`,
          role: sampleText.length > 30 ? 'heading' : 'badge',
          sampleText,
          fontCandidates: [globalData.fontPairing?.primary || 'unknown'],
          freeFallback: globalData.fontPairing?.substitute || 'system-ui',
          size: { value: t.size || '16px', source: 'estimated' },
          weight: { value: t.weight || '400', source: 'estimated' },
          lineHeight: { value: '1.4', source: 'estimated' },
          letterSpacing: { value: t.spacing || 'normal', source: 'estimated' },
          color: { value: fgColor.toUpperCase(), source: assignColorSource(fgColor, measuredPalette, true) },
        });
      }
    }

    // Cards
    if (inspection.cards) {
      for (let cIdx = 0; cIdx < inspection.cards.length; cIdx++) {
        const c = inspection.cards[cIdx];
        const cardBox = c.box_2d
          ? { ymin: c.box_2d[0], xmin: c.box_2d[1], ymax: c.box_2d[2], xmax: c.box_2d[3] }
          : rBox;

        // T4: Gradient stops come from measureRegion, not the model
        let gradStops: import('../types').SourcedValue<string>[] = [];
        if (measuredRegion) {
          gradStops = [
            { value: measuredRegion.topColor.toUpperCase(), source: 'measured' },
            { value: measuredRegion.middleColor.toUpperCase(), source: 'measured' },
            { value: measuredRegion.bottomColor.toUpperCase(), source: 'measured' },
          ];
        } else if (c.gradientStops && c.gradientStops.length > 0) {
          gradStops = c.gradientStops.map((hex) => ({
            value: hex.toUpperCase(),
            source: assignColorSource(hex, measuredPalette),
          }));
        } else {
          gradStops = [{ value: '#1A1A1A', source: 'estimated' }];
        }

        const cardLabel = normalizeCardLabel(c.label, cIdx);
        cardsContainers.push({
          id: `card-${rIdx + 1}-${cIdx + 1}`,
          label: cardLabel,
          box: cardBox,
          radius: { value: c.radius || '16px', source: 'estimated' },
          padding: { value: '24px', source: 'estimated' },
          gradientStops: gradStops as any,
          gloss: { value: 'matte', source: 'estimated' },
          shadow: { value: c.shadow || '0 10px 30px rgba(0,0,0,0.5)', source: 'estimated' },
          rotation: { value: c.rotation || '0deg', source: 'estimated' },
          overlap: { value: 'none', source: 'estimated' },
          crop: { value: c.crop || 'contained', source: 'estimated' },
        });
      }
    }

    // Characters
    if (inspection.characters) {
      for (let chIdx = 0; chIdx < inspection.characters.length; chIdx++) {
        const ch = inspection.characters[chIdx];
        const chBox = ch.box_2d
          ? { ymin: ch.box_2d[0], xmin: ch.box_2d[1], ymax: ch.box_2d[2], xmax: ch.box_2d[3] }
          : rBox;

        characters.push({
          id: `char-${characters.length + 1}`,
          label: ch.label || `Character ${characters.length + 1}`,
          description: ch.description || 'unknown',
          colors: [{ value: '#0063E1', source: assignColorSource('#0063E1', measuredPalette) }],
          materials: { value: '3D smooth vinyl', source: 'estimated' },
          position: { value: 'center', source: 'estimated' },
          box: chBox,
          crop: { value: ch.crop || 'full-figure', source: 'estimated' },
        });
      }
    }

    // Props
    if (inspection.props) {
      for (let pIdx = 0; pIdx < inspection.props.length; pIdx++) {
        const pr = inspection.props[pIdx];
        const prBox = pr.box_2d
          ? { ymin: pr.box_2d[0], xmin: pr.box_2d[1], ymax: pr.box_2d[2], xmax: pr.box_2d[3] }
          : rBox;

        props.push({
          id: `prop-${props.length + 1}`,
          label: pr.label || `Prop ${props.length + 1}`,
          description: pr.description || 'unknown',
          colors: [{ value: '#F2FC4E', source: assignColorSource('#F2FC4E', measuredPalette) }],
          materials: { value: 'matte geometry', source: 'estimated' },
          position: { value: 'floating', source: 'estimated' },
          box: prBox,
          crop: { value: pr.crop || 'uncropped', source: 'estimated' },
        });
      }
    }

    // Icons
    if (inspection.icons) {
      for (let iIdx = 0; iIdx < inspection.icons.length; iIdx++) {
        const ic = inspection.icons[iIdx];
        const icBox = ic.box_2d
          ? { ymin: ic.box_2d[0], xmin: ic.box_2d[1], ymax: ic.box_2d[2], xmax: ic.box_2d[3] }
          : undefined;

        icons.push({
          id: `icon-${icons.length + 1}`,
          name: ic.name || 'icon',
          label: ic.name || 'icon',
          description: ic.description || 'outline',
          size: { value: '20px', source: 'estimated' },
          color: { value: '#FFFFFF', source: assignColorSource('#FFFFFF', measuredPalette) },
          box: icBox,
          position: { value: 'inline', source: 'estimated' },
        });
      }
    }
  }

  // Merge cards detected in locate elements
  let cardNameIdx = 0;
  for (const el of locateElements) {
    if (el.kind === 'card' || el.label.toLowerCase().includes('card') || el.box_2d[0] > 600) {
      let cardLabel = el.text || el.label.replace(/^card\s*/i, '').replace(/\s*card$/i, '').trim();
      if (
        !cardLabel ||
        cardLabel.toLowerCase().startsWith('card ') ||
        cardLabel.toLowerCase().startsWith('bottom card') ||
        cardLabel.toLowerCase().startsWith('bottom_card') ||
        /^(?:bottom[\s_-]*)?card[\s_-]*\d+$/i.test(cardLabel)
      ) {
        cardLabel = defaultCardNames[cardNameIdx % defaultCardNames.length];
        cardNameIdx++;
      }
      const alreadyHas = cardsContainers.some(
        (c) => c.label.toLowerCase() === cardLabel.toLowerCase()
      );
      if (!alreadyHas && cardLabel) {
        addCopy(cardLabel, `Card ${cardLabel}`);
        cardsContainers.push({
          id: `card-loc-${cardsContainers.length + 1}`,
          label: cardLabel,
          box: { ymin: el.box_2d[0], xmin: el.box_2d[1], ymax: el.box_2d[2], xmax: el.box_2d[3] },
          radius: { value: '16px', source: 'estimated' },
          padding: { value: '24px', source: 'estimated' },
          gradientStops: [{ value: '#1C1C1C', source: 'measured' }],
          gloss: { value: 'matte', source: 'estimated' },
          shadow: { value: '0 10px 30px rgba(0,0,0,0.5)', source: 'estimated' },
          rotation: { value: '0deg', source: 'estimated' },
          overlap: { value: 'none', source: 'estimated' },
          crop: { value: 'contained', source: 'estimated' },
        });
      }
    }
  }

  // Merge props detected in locate elements
  for (const el of locateElements) {
    if (
      el.kind === 'prop' ||
      el.label.toLowerCase().includes('prop') ||
      el.label.toLowerCase().includes('shape')
    ) {
      const propLabel = el.label || `Prop ${props.length + 1}`;
      const alreadyHas = props.some((p) => p.label.toLowerCase() === propLabel.toLowerCase());
      if (!alreadyHas) {
        props.push({
          id: `prop-loc-${props.length + 1}`,
          label: propLabel,
          description: el.label || 'floating geometric prop',
          colors: [{ value: '#F2FC4E', source: assignColorSource('#F2FC4E', measuredPalette) }],
          materials: { value: 'matte geometry', source: 'estimated' },
          position: { value: 'floating', source: 'estimated' },
          box: { ymin: el.box_2d[0], xmin: el.box_2d[1], ymax: el.box_2d[2], xmax: el.box_2d[3] },
          crop: { value: 'uncropped', source: 'estimated' },
        });
      }
    }
  }

  // 7. VisualFrame (T5: Store cropW and cropH, real conversion rules)
  const visualSpec: VisualSpec = {
    frame: {
      referenceWidth: 1440,
      cropW,
      cropH,
      coordinateSystem: `0-1000 normalized frame converted to a 1440x${refH} reference canvas`,
      conversionRule: `Reference coordinates: X = round(normalized_xmin * 1440 / 1000), Y = round(normalized_ymin * ${refH} / 1000), width = round((normalized_xmax - normalized_xmin) * 1440 / 1000), height = round((normalized_ymax - normalized_ymin) * ${refH} / 1000) (ref canvas: 1440x${refH}px)`,
      detectedCrop: measurements.cropRect,
    },
    background,
    paletteByRole,
    copyInventory: Array.from(copyMap.values()),
    elementInventory,
    typographyPerElement,
    cardsContainers,
    characters,
    props,
    icons,
    shadowsAndShine: (globalData.shadows || []).map((sh, idx) => ({
      id: `shadow-${idx + 1}`,
      target: sh.name || 'cards',
      type: 'shadow',
      value: { value: sh.value, source: 'estimated' },
      lightDirection: { value: 'top-down', source: 'estimated' },
    })),
    motion: [
      {
        element: 'Interactive cards and buttons',
        trigger: 'hover',
        description: 'Smooth scale and opacity transitions',
        source: 'inferred',
      },
    ],
    dosAndDonts: {
      dos: globalData.dosAndDonts?.dos || [],
      donts: globalData.dosAndDonts?.donts || [],
    },
  };

  const primaryFontName = globalData.fontPairing?.primary || 'unknown';
  const substituteFont = globalData.fontPairing?.substitute || 'system-ui';

  return {
    meta: {
      title,
      theme,
      industry: 'saas',
      styleTags: [],
      sections: [],
      summary: globalData.summary || 'unknown',
      description: globalData.description || 'unknown',
    },
    colors,
    measuredPalette,
    typography: {
      primaryFont: {
        name: primaryFontName,
        substitute: substituteFont,
        role: 'Primary typeface',
        weights: [400, 600, 700],
        sizes: ['14px', '16px', '24px', '48px'],
        lineHeight: '1.4',
        letterSpacing: 'normal',
        token: '--font-primary',
      },
      secondaryFont: globalData.fontPairing?.secondary
        ? {
            name: globalData.fontPairing.secondary,
            substitute: 'system-ui',
            role: 'Secondary typeface',
            weights: [400, 600],
            sizes: ['14px', '16px'],
            lineHeight: '1.4',
            letterSpacing: 'normal',
            token: '--font-secondary',
          }
        : undefined,
      typeScale: [],
    },
    spacing: {
      baseUnit: globalData.spacing?.baseUnit || 8,
      density: globalData.spacing?.density || 'comfortable',
      scale: [],
      radii: (globalData.radii || []).map((r) => ({ element: r.element, value: r.value })),
      shadows: (globalData.shadows || []).map((s) => ({ name: s.name, value: s.value, token: `--shadow-${slug(s.name)}` })),
      layout: {
        pageMaxWidth: globalData.spacing?.pageMaxWidth || '1440px',
        sectionGap: '64px',
        cardPadding: '24px',
        elementGap: '16px',
      },
    },
    surfaces: [],
    components: [],
    dosAndDonts: {
      dos: globalData.dosAndDonts?.dos || [],
      donts: globalData.dosAndDonts?.donts || [],
    },
    visualSpec,
    reducedDetail: isReducedDetail,
    unresolvedRegions: unresolvedRegions && unresolvedRegions.length > 0 ? unresolvedRegions : undefined,
  };
}
