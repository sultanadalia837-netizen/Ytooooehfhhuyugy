/**
 * Pipeline orchestrator v2.1.0
 * Short Passes (A: Locate, B: Regions, C: Global, Assemble)
 * T3 Short passes, T4 Provenance & Palette, T5 Coordinates, T6 Deadline & Resume
 */
import { nanoid } from 'nanoid';
import {
  MAX_FILES,
  TALL_RATIO,
  SEGMENT_RATIO,
  PIPELINE_VERSION,
  REGION_DEADLINE_MS,
  GLOBAL_CONCURRENCY,
} from '../config';
import { AppError, getErrorMessage } from './errors';
import { computeFilesHash, makeCacheKey } from './hash';
import { processUploadFile, PreparedImage } from './prepare';
import { measureImages, measureRegion } from './measure';
import {
  callAiAnalyze,
  callAiLocate,
  callAiZoomRegion,
  callAiGlobal,
} from './ai';
import { assembleDesignSpec, groupBoxesIntoRegions } from './assemble';
import { renderDesignMd } from './render';
import { cropAndStoreAssets } from './assets';
import {
  saveResult,
  getCachedResultId,
  getResult,
  setSiteQueue,
  getPassCache,
  setPassCache,
} from '../storage/local';
import {
  PipelineEvent,
  PipelineOptions,
  SiteGroup,
  Result,
  ResultImage,
  Box2D,
  Measurements,
  LocateElement,
  RegionInspection,
  GlobalInspection,
} from '../types';

/**
 * Splits tall screenshots into overlapping vertical tiles if necessary.
 */
async function splitTallImageIntoTiles(
  prepared: PreparedImage
): Promise<{ base64: string; mimeType: string }[]> {
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return [{ base64: prepared.aiBase64, mimeType: prepared.aiMimeType || 'image/png' }];
  }

  const { width, height, dataUrl } = prepared;
  const ratio = height / (width || 1);

  if (ratio <= TALL_RATIO) {
    return [{ base64: prepared.aiBase64, mimeType: prepared.aiMimeType || 'image/png' }];
  }

  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const tileHeight = Math.round(width * SEGMENT_RATIO);
      const overlap = Math.round(tileHeight * 0.2);
      const step = tileHeight - overlap;
      const tiles: { base64: string; mimeType: string }[] = [];

      let y = 0;
      let count = 0;

      while (y < height && count < 3) {
        const currentTileH = Math.min(tileHeight, height - y);
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = currentTileH;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, y, width, currentTileH, 0, 0, width, currentTileH);
          const tileDataUrl = canvas.toDataURL('image/png');
          tiles.push({
            base64: tileDataUrl.replace(/^data:image\/[a-z0-9+.-]+;base64,/, ''),
            mimeType: 'image/png',
          });
        }
        y += step;
        count++;
        if (y + currentTileH >= height) break;
      }

      resolve(tiles.length > 0 ? tiles : [{ base64: prepared.aiBase64, mimeType: prepared.aiMimeType || 'image/png' }]);
    };
    img.onerror = () => {
      resolve([{ base64: prepared.aiBase64, mimeType: prepared.aiMimeType || 'image/png' }]);
    };
    img.src = dataUrl;
  });
}

/**
 * Downscale image to 1024 on long side for Pass C (global)
 */
async function downscaleImageTo1024(dataUrl: string): Promise<string> {
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return dataUrl.replace(/^data:image\/[a-z0-9+.-]+;base64,/, '');
  }

  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      let w = img.naturalWidth;
      let h = img.naturalHeight;
      const longSide = Math.max(w, h);
      if (longSide > 1024) {
        if (w >= h) {
          h = Math.round((h * 1024) / w);
          w = 1024;
        } else {
          w = Math.round((w * 1024) / h);
          h = 1024;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(dataUrl.replace(/^data:image\/[a-z0-9+.-]+;base64,/, ''));
        return;
      }
      ctx.drawImage(img, 0, 0, w, h);
      const out = canvas.toDataURL('image/png');
      resolve(out.replace(/^data:image\/[a-z0-9+.-]+;base64,/, ''));
    };
    img.onerror = () => {
      resolve(dataUrl.replace(/^data:image\/[a-z0-9+.-]+;base64,/, ''));
    };
    img.src = dataUrl;
  });
}

/**
 * Crop region from full-res image with 8% padding, upscale to >= 768 px on long side
 */
async function cropAndUpscaleRegion(
  dataUrl: string,
  box: Box2D,
  targetMinLongSide = 768
): Promise<string> {
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return dataUrl.replace(/^data:image\/[a-z0-9+.-]+;base64,/, '');
  }

  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const imgW = img.naturalWidth;
      const imgH = img.naturalHeight;

      const padY = Math.round((box.ymax - box.ymin) * 0.08);
      const padX = Math.round((box.xmax - box.xmin) * 0.08);

      const yminNorm = Math.max(0, box.ymin - padY);
      const ymaxNorm = Math.min(1000, box.ymax + padY);
      const xminNorm = Math.max(0, box.xmin - padX);
      const xmaxNorm = Math.min(1000, box.xmax + padX);

      const srcX = Math.round((xminNorm * imgW) / 1000);
      const srcY = Math.round((yminNorm * imgH) / 1000);
      const srcW = Math.max(1, Math.round(((xmaxNorm - xminNorm) * imgW) / 1000));
      const srcH = Math.max(1, Math.round(((ymaxNorm - yminNorm) * imgH) / 1000));

      const longSide = Math.max(srcW, srcH);
      const scale = longSide < targetMinLongSide ? targetMinLongSide / longSide : 1;
      const destW = Math.round(srcW * scale);
      const destH = Math.round(srcH * scale);

      const canvas = document.createElement('canvas');
      canvas.width = destW;
      canvas.height = destH;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(dataUrl.replace(/^data:image\/[a-z0-9+.-]+;base64,/, ''));
        return;
      }
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(img, srcX, srcY, srcW, srcH, 0, 0, destW, destH);
      const out = canvas.toDataURL('image/png');
      resolve(out.replace(/^data:image\/[a-z0-9+.-]+;base64,/, ''));
    };
    img.onerror = () => {
      resolve(dataUrl.replace(/^data:image\/[a-z0-9+.-]+;base64,/, ''));
    };
    img.src = dataUrl;
  });
}

export async function runPipeline(files: File[], opts: PipelineOptions): Promise<void> {
  const { signal, onEvent, requestChoice } = opts;

  try {
    if (signal.aborted) throw new AppError('cancelled');

    // ----------------------------------------------------
    // STEP 1: CHECK (hash, validate client rules, prepare)
    // ----------------------------------------------------
    onEvent({ type: 'step', step: 'check', status: 'active' });

    if (files.length === 0) {
      throw new AppError('network', 'No files provided.');
    }

    if (files.length > MAX_FILES) {
      onEvent({
        type: 'rejected',
        items: files.slice(MAX_FILES).map((f) => ({
          fileName: f.name,
          code: 'too_many_files',
        })),
      });
      return;
    }

    const preparedList: PreparedImage[] = [];
    const clientRejectedItems: { fileName: string; code: string; reason?: string }[] = [];

    for (const file of files) {
      if (signal.aborted) throw new AppError('cancelled');
      const prepared = await processUploadFile(file);
      if (prepared.issueCode) {
        clientRejectedItems.push({
          fileName: file.name,
          code: prepared.issueCode,
          reason: prepared.issueReason || getErrorMessage(prepared.issueCode),
        });
      }
      preparedList.push(prepared);
    }

    if (clientRejectedItems.length > 0) {
      onEvent({ type: 'rejected', items: clientRejectedItems });
      return;
    }

    const hash = await computeFilesHash(files);
    const cacheKey = makeCacheKey(hash);

    // Check complete Result cache in IndexedDB
    const cachedId = await getCachedResultId(cacheKey);
    if (cachedId) {
      const existing = await getResult(cachedId);
      if (existing) {
        onEvent({ type: 'step', step: 'check', status: 'done' });
        onEvent({ type: 'cache_hit', resultId: cachedId });
        onEvent({ type: 'done', resultIds: [cachedId] });
        return;
      }
    }

    onEvent({ type: 'step', step: 'check', status: 'done' });

    // ----------------------------------------------------
    // STEP 2: MEASURE (initial global measurement)
    // ----------------------------------------------------
    if (signal.aborted) throw new AppError('cancelled');
    onEvent({ type: 'step', step: 'measure', status: 'active' });

    const globalMeasurements = await measureImages(
      preparedList.map((p) => ({
        width: p.width,
        height: p.height,
        dataUrl: p.dataUrl,
      }))
    );

    onEvent({ type: 'step', step: 'measure', status: 'done' });

    // ----------------------------------------------------
    // STEP 3: ANALYZE (verify website, multi-site detection)
    // ----------------------------------------------------
    if (signal.aborted) throw new AppError('cancelled');
    onEvent({ type: 'step', step: 'analyze', status: 'active' });

    const analyzeResult = await callAiAnalyze(
      preparedList.map((p) => ({
        base64: p.aiBase64,
        mimeType: p.aiMimeType || 'image/png',
      })),
      signal
    );

    if (!analyzeResult.isWebsite) {
      const code = analyzeResult.rejectionCode || 'not_website';
      const reason = analyzeResult.rejectionReason || getErrorMessage(code);
      onEvent({
        type: 'rejected',
        items: files.map((f) => ({ fileName: f.name, code, reason })),
      });
      return;
    }

    let sitesToProcess: SiteGroup[] = [];
    if (analyzeResult.sites && analyzeResult.sites.length > 1) {
      const choice = await requestChoice(analyzeResult.sites);
      const chosenSiteIds = choice.siteIds;
      sitesToProcess = analyzeResult.sites.filter((s) => chosenSiteIds.includes(s.id));
      const unchosenSites = analyzeResult.sites.filter((s) => !chosenSiteIds.includes(s.id));
      await setSiteQueue(unchosenSites);
    } else if (analyzeResult.sites && analyzeResult.sites.length === 1) {
      sitesToProcess = analyzeResult.sites;
      await setSiteQueue([]);
    } else {
      sitesToProcess = [
        {
          id: 'site-1',
          label: 'unknown',
          description: 'unknown',
          sections: [],
          imageIndices: preparedList.map((_, i) => i),
        },
      ];
      await setSiteQueue([]);
    }

    onEvent({ type: 'step', step: 'analyze', status: 'done' });

    // ----------------------------------------------------
    // STEP 4: MULTI-PASS EXTRACTION (Pass A, B, C, Assemble)
    // ----------------------------------------------------
    if (signal.aborted) throw new AppError('cancelled');
    onEvent({ type: 'step', step: 'extract', status: 'active' });

    const createdResultIds: string[] = [];

    for (const site of sitesToProcess) {
      if (signal.aborted) throw new AppError('cancelled');
      const pipelineStartTime = Date.now();

      const siteImages = (site.imageIndices || [0])
        .filter((idx) => idx >= 0 && idx < preparedList.length)
        .map((idx) => preparedList[idx]);
      const effectiveImages = siteImages.length > 0 ? siteImages : preparedList;
      const primaryImg = effectiveImages[0];

      // --------------------------------------------------
      // Pass A: Locate
      // --------------------------------------------------
      onEvent({ type: 'step', step: 'locate', status: 'active' });
      const locateCacheKey = `${hash}_passA_locate_${PIPELINE_VERSION}`;
      let locateElements: LocateElement[] | undefined = await getPassCache<LocateElement[]>(locateCacheKey);

      if (!locateElements) {
        locateElements = await callAiLocate(
          [{ base64: primaryImg.aiBase64, mimeType: primaryImg.aiMimeType || 'image/png' }],
          signal
        );
        if (locateElements && locateElements.length > 0) {
          await setPassCache(locateCacheKey, locateElements);
        }
      }
      onEvent({ type: 'step', step: 'locate', status: 'done' });

      // Detect boxes from locate elements
      const detectedBoxes: Box2D[] = (locateElements || []).map((el) => {
        const [ymin, xmin, ymax, xmax] = el.box_2d;
        return { ymin, xmin, ymax, xmax };
      });

      // Group boxes into at most 6 regions
      const regionBoxes = groupBoxesIntoRegions(detectedBoxes);

      // Measure site with region boxes
      const siteMeasurements: Measurements = await measureImages(
        effectiveImages.map((p) => ({
          width: p.width,
          height: p.height,
          dataUrl: p.dataUrl,
        })),
        regionBoxes
      );

      // --------------------------------------------------
      // Pass C: Global (runs in parallel with Pass B)
      // --------------------------------------------------
      onEvent({ type: 'step', step: 'global', status: 'active' });
      const globalCacheKey = `${hash}_passC_global_${PIPELINE_VERSION}`;

      const globalPromise = (async (): Promise<GlobalInspection> => {
        const cachedGlobal = await getPassCache<GlobalInspection>(globalCacheKey);
        if (cachedGlobal) return cachedGlobal;

        const downscaled1024 = await downscaleImageTo1024(primaryImg.dataUrl);
        const globalRes = await callAiGlobal(downscaled1024, signal);
        if (globalRes) {
          await setPassCache(globalCacheKey, globalRes);
        }
        return globalRes;
      })();

      // --------------------------------------------------
      // Pass B: Regions (concurrency 2, deadline 100s)
      // --------------------------------------------------
      const regionsData: { box: Box2D; inspection: RegionInspection; measuredRegion?: any }[] = [];
      const unresolvedRegions: Box2D[] = [];

      // Concurrency 2 executor for region calls
      const runRegion = async (rBox: Box2D, index: number) => {
        // T6: Stop launching new region calls after 100s
        const elapsed = Date.now() - pipelineStartTime;
        if (elapsed >= REGION_DEADLINE_MS) {
          console.warn(`[Pipeline] Region deadline (100s) reached at ${elapsed}ms. Marking region as unresolved.`);
          unresolvedRegions.push(rBox);
          return;
        }

        const boxKey = `${rBox.ymin}_${rBox.xmin}_${rBox.ymax}_${rBox.xmax}`;
        const regionCacheKey = `${hash}_passB_region_${boxKey}_${PIPELINE_VERSION}`;

        onEvent({
          type: 'step',
          step: 'zoom',
          status: 'active',
          subStep: `zoom ${index + 1} of ${regionBoxes.length}`,
        });

        try {
          const cachedRegion = await getPassCache<RegionInspection>(regionCacheKey);
          const measuredRegion =
            siteMeasurements.regions?.find(
              (r) => r.box.ymin === rBox.ymin && r.box.xmin === rBox.xmin
            ) || siteMeasurements.regions?.[index];

          if (cachedRegion) {
            regionsData.push({ box: rBox, inspection: cachedRegion, measuredRegion });
            return;
          }

          const croppedBase64 = await cropAndUpscaleRegion(primaryImg.dataUrl, rBox, 768);
          const inspection = await callAiZoomRegion(
            croppedBase64,
            measuredRegion || { palette: siteMeasurements.palette.slice(0, 6) },
            signal
          );

          if (inspection) {
            await setPassCache(regionCacheKey, inspection);
            regionsData.push({ box: rBox, inspection, measuredRegion });
          } else {
            unresolvedRegions.push(rBox);
          }
        } catch (e) {
          console.warn(`Region inspection ${index + 1} failed or skipped:`, e);
          unresolvedRegions.push(rBox);
        }
      };

      // Execute regions with concurrency 2
      const executing: Promise<void>[] = [];
      for (let i = 0; i < regionBoxes.length; i++) {
        if (signal.aborted) throw new AppError('cancelled');
        const p = runRegion(regionBoxes[i], i);
        executing.push(p);

        if (executing.length >= GLOBAL_CONCURRENCY) {
          await Promise.race(executing);
          // Clean finished
          for (let j = executing.length - 1; j >= 0; j--) {
            // Check if settled
          }
        }
      }
      await Promise.all(executing);

      // Await Pass C global
      const globalData = await globalPromise;
      onEvent({ type: 'step', step: 'global', status: 'done' });
      onEvent({ type: 'step', step: 'zoom', status: 'done' });

      // --------------------------------------------------
      // Assemble: Assemble DesignSpec with T4 & T5
      // --------------------------------------------------
      onEvent({ type: 'step', step: 'assemble', status: 'active' });

      const cropW = siteMeasurements.cropRect?.width || primaryImg.width || 1440;
      const cropH = siteMeasurements.cropRect?.height || primaryImg.height || 1440;

      const spec = assembleDesignSpec({
        globalData,
        locateElements: locateElements || [],
        regionsData,
        measurements: siteMeasurements,
        frameDimensions: { cropW, cropH },
        isReducedDetail: false,
        unresolvedRegions: unresolvedRegions.length > 0 ? unresolvedRegions : undefined,
      });

      if (site.label && site.label !== 'Untitled Site' && site.label !== 'unknown') {
        spec.meta.title = site.label.slice(0, 60);
      }

      onEvent({ type: 'step', step: 'assemble', status: 'done' });

      // ----------------------------------------------------
      // STEP 5: VALIDATE & RENDER & ASSET CROP
      // ----------------------------------------------------
      onEvent({ type: 'step', step: 'validate', status: 'active' });
      const newId = nanoid(10);

      if (primaryImg.dataUrl) {
        try {
          await cropAndStoreAssets(newId, primaryImg.dataUrl, spec);
        } catch (e) {
          console.warn('Asset crop non-fatal:', e);
        }
      }

      const markdown = renderDesignMd(spec);

      const resultImages: ResultImage[] = effectiveImages.map((p) => ({
        name: p.file.name,
        width: p.width,
        height: p.height,
        thumbDataUrl: p.thumbDataUrl,
        dataUrl: p.dataUrl,
        cropRect: siteMeasurements.cropRect,
      }));

      const resultObj: Result = {
        id: newId,
        createdAt: Date.now(),
        cacheKey: sitesToProcess.length === 1 ? cacheKey : `${cacheKey}_${site.id}`,
        title: spec.meta.title,
        tags: {
          industry: spec.meta.industry !== 'unknown' ? [spec.meta.industry] : [],
          style: spec.meta.styleTags || [],
          sections: spec.meta.sections || [],
        },
        markdown,
        spec,
        images: resultImages,
        reducedDetail: spec.reducedDetail,
        unresolvedRegions: spec.unresolvedRegions,
      };

      await saveResult(resultObj);
      createdResultIds.push(newId);
    }

    onEvent({ type: 'step', step: 'extract', status: 'done' });
    onEvent({ type: 'step', step: 'validate', status: 'done' });
    onEvent({ type: 'done', resultIds: createdResultIds });
  } catch (err: any) {
    if (signal.aborted || err?.code === 'cancelled' || err?.message === 'cancelled') {
      onEvent({ type: 'error', error: new AppError('cancelled') });
    } else {
      onEvent({
        type: 'error',
        error: err instanceof AppError ? err : new AppError('network', err?.message),
      });
    }
  }
}
