/**
 * Gemini API handling & Multi-Pass Visual Inspection
 * T0 Instrumentation, T1 Timeouts/Retries/Limiter, T2 No Silent Downgrade, T3 Short Passes
 */
import { GoogleGenAI, ThinkingLevel } from '@google/genai';
import {
  GEMINI_DETAIL_MODELS,
  GEMINI_LITE_MODELS,
  GEMINI_DETAIL_PRIMARY,
  GEMINI_LITE_PRIMARY,
  GLOBAL_CONCURRENCY,
  MIN_REQUEST_GAP_MS,
  CALL_TIMEOUT_MS,
  CLIENT_CALL_TIMEOUT_MS,
  MAX_RETRY_DELAY_MS,
  LOCATE_MAX_OUTPUT_TOKENS,
  REGION_MAX_OUTPUT_TOKENS,
  GLOBAL_MAX_OUTPUT_TOKENS,
  ANALYZE_MAX_OUTPUT_TOKENS,
  ANALYZE_PROMPT,
  LOCATE_PROMPT,
  REGION_PROMPT,
  GLOBAL_PROMPT,
} from '../config';
import { AppError, mapError } from './errors';
import {
  AnalyzeResult,
  Box2D,
  LocateElement,
  RegionInspection,
  GlobalInspection,
  DesignSpec,
  Measurements,
} from '../types';
import { validateAnalyzeResult } from './validate';

// Lazy initialize SDK on server / Node side
let aiClient: GoogleGenAI | null = null;
let registeredAvailableModelIds: Set<string> | null = null;

export function getAiClient(): GoogleGenAI {
  if (aiClient) return aiClient;
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const dotenv = require('dotenv');
    dotenv.config({ override: true });
  } catch {}
  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    throw new AppError('ai_config', 'GEMINI_API_KEY environment variable is not set.');
  }
  aiClient = new GoogleGenAI({
    apiKey: key,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build-loupe-v2',
      },
    },
  });
  return aiClient;
}

// ----------------------------------------------------------------------------
// T0: Instrumentation & Model Registry
// ----------------------------------------------------------------------------

export async function initModelRegistry(ai?: GoogleGenAI): Promise<Set<string>> {
  if (registeredAvailableModelIds) return registeredAvailableModelIds;
  const client = ai || getAiClient();
  const available = new Set<string>();

  try {
    const listRes = await client.models.list();
    for await (const m of listRes) {
      if (m.name) {
        const id = m.name.replace(/^models\//, '');
        available.add(id);
      }
    }
    console.log(`[Model Registry] Available Gemini models in project: ${available.size} models found`);

    // Verify detail tier models
    const activeDetail = GEMINI_DETAIL_MODELS.filter((id) => available.has(id));
    const droppedDetail = GEMINI_DETAIL_MODELS.filter((id) => !available.has(id));
    if (droppedDetail.length > 0) {
      console.warn(`[Model Registry] Dropped unlisted detail models: ${droppedDetail.join(', ')}`);
    }
    console.log(`[Model Registry] Active detail models: ${activeDetail.join(', ') || 'none'}`);

    // Verify lite tier models
    const activeLite = GEMINI_LITE_MODELS.filter((id) => available.has(id));
    const droppedLite = GEMINI_LITE_MODELS.filter((id) => !available.has(id));
    if (droppedLite.length > 0) {
      console.warn(`[Model Registry] Dropped unlisted lite models: ${droppedLite.join(', ')}`);
    }
    console.log(`[Model Registry] Active lite models: ${activeLite.join(', ') || 'none'}`);

    registeredAvailableModelIds = available;
    return available;
  } catch (err: any) {
    console.warn(`[Model Registry] Failed to list models: ${err?.message}. Using configured defaults.`);
    registeredAvailableModelIds = new Set([...GEMINI_DETAIL_MODELS, ...GEMINI_LITE_MODELS]);
    return registeredAvailableModelIds;
  }
}

export function getAvailableModels(): Set<string> {
  return registeredAvailableModelIds || new Set([...GEMINI_DETAIL_MODELS, ...GEMINI_LITE_MODELS]);
}

export interface CallLogItem {
  passName: string;
  model: string;
  durationMs: number;
  httpStatus: number;
  finishReason?: string;
  outputTokens?: number;
  promptTokens?: number;
  error?: string;
}

export class RunMetricsTracker {
  private logs: CallLogItem[] = [];
  private startTime = Date.now();
  public reducedDetail = false;
  public unresolvedRegionsCount = 0;

  record(item: CallLogItem) {
    this.logs.push(item);
  }

  printSummary() {
    const totalDuration = Date.now() - this.startTime;
    const usedModels = Array.from(new Set(this.logs.map((l) => l.model)));
    const totalOutputTokens = this.logs.reduce((sum, l) => sum + (l.outputTokens || 0), 0);
    const totalPromptTokens = this.logs.reduce((sum, l) => sum + (l.promptTokens || 0), 0);
    console.log(
      `[Pipeline Run Summary] passes=${this.logs.length} totalDuration=${totalDuration}ms models=${JSON.stringify(
        usedModels
      )} tokens={prompt: ${totalPromptTokens}, output: ${totalOutputTokens}} reducedDetail=${this.reducedDetail} unresolvedRegions=${this.unresolvedRegionsCount}`
    );
  }
}

// ----------------------------------------------------------------------------
// T1: Global Concurrency Limiter
// ----------------------------------------------------------------------------

class ConcurrencyLimiter {
  private active = 0;
  private queue: (() => void)[] = [];
  private lastStart = 0;
  private maxConcurrency: number;
  private minGapMs: number;

  constructor(maxConcurrency: number, minGapMs: number) {
    this.maxConcurrency = maxConcurrency;
    this.minGapMs = minGapMs;
  }

  async acquire(signal?: AbortSignal): Promise<void> {
    if (signal?.aborted) throw new AppError('cancelled');
    while (this.active >= this.maxConcurrency) {
      await new Promise<void>((resolve, reject) => {
        const onAbort = () => reject(new AppError('cancelled'));
        signal?.addEventListener('abort', onAbort, { once: true });
        this.queue.push(() => {
          signal?.removeEventListener('abort', onAbort);
          resolve();
        });
      });
    }

    const now = Date.now();
    const elapsed = now - this.lastStart;
    if (elapsed < this.minGapMs) {
      await new Promise((r) => setTimeout(r, this.minGapMs - elapsed));
    }
    this.active++;
    this.lastStart = Date.now();
  }

  release(): void {
    this.active = Math.max(0, this.active - 1);
    const next = this.queue.shift();
    if (next) next();
  }
}

const globalLimiter = new ConcurrencyLimiter(GLOBAL_CONCURRENCY, MIN_REQUEST_GAP_MS);

// Helper sleep
function sleep(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) return reject(new AppError('cancelled'));
    const timer = setTimeout(resolve, ms);
    signal?.addEventListener(
      'abort',
      () => {
        clearTimeout(timer);
        reject(new AppError('cancelled'));
      },
      { once: true }
    );
  });
}

// Cleans JSON response
export function cleanJsonResponse(text: string): string {
  let cleaned = (text || '').trim();
  if (cleaned.startsWith('```json')) {
    cleaned = cleaned.replace(/^```json\s*/, '').replace(/\s*```$/, '');
  } else if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```\s*/, '').replace(/\s*```$/, '');
  }
  return cleaned.trim();
}

// ----------------------------------------------------------------------------
// T1 & T2: Single Call Policy with Hard 60s Timeout, 1 Retry, and No Silent Downgrade
// ----------------------------------------------------------------------------

export interface GeminiCallParams {
  passName: string;
  tier: 'detail' | 'lite' | 'analyze';
  contents: any[];
  systemInstruction: string;
  maxOutputTokens: number;
  thinkingLevel?: 'LOW' | 'MINIMAL';
  signal?: AbortSignal;
  tracker?: RunMetricsTracker;
}

export interface GeminiCallResult {
  text: string;
  modelUsed: string;
  isReducedDetail: boolean;
  finishReason?: string;
  usageMetadata?: any;
}

const quotaExhaustedModels = new Set<string>();

export async function callGeminiWithPolicy(params: GeminiCallParams): Promise<GeminiCallResult> {
  const ai = getAiClient();
  const available = getAvailableModels();

  let tierModels: string[];
  let fallbackToLowerTierAllowed = false;

  if (params.tier === 'detail') {
    tierModels = GEMINI_DETAIL_MODELS.filter((id) => available.has(id) && !quotaExhaustedModels.has(id));
    fallbackToLowerTierAllowed = true;
  } else if (params.tier === 'analyze') {
    tierModels = [GEMINI_LITE_PRIMARY, ...GEMINI_DETAIL_MODELS].filter(
      (id) => available.has(id) && !quotaExhaustedModels.has(id)
    );
    if (tierModels.length === 0) tierModels = [GEMINI_LITE_PRIMARY];
  } else {
    // Lite tier
    tierModels = GEMINI_LITE_MODELS.filter((id) => available.has(id));
    if (tierModels.length === 0) tierModels = [GEMINI_LITE_PRIMARY];
  }

  const liteTierModels = GEMINI_LITE_MODELS.filter((id) => available.has(id));
  const fallbackModels = fallbackToLowerTierAllowed ? liteTierModels : [];

  let lastError: any = null;

  // Try tier models in order
  const modelQueue: { model: string; isLowerTier: boolean }[] = [
    ...tierModels.map((m) => ({ model: m, isLowerTier: false })),
    ...fallbackModels.map((m) => ({ model: m, isLowerTier: true })),
  ];

  for (const { model, isLowerTier } of modelQueue) {
    if (params.signal?.aborted) throw new AppError('cancelled');

    // Exactly one retry per call policy (attempt 0 and attempt 1 retry)
    let currentMaxTokens = params.maxOutputTokens;
    let attempt = 0;

    while (attempt <= 1) {
      if (params.signal?.aborted) throw new AppError('cancelled');
      await globalLimiter.acquire(params.signal);

      const controller = new AbortController();
      const onParentAbort = () => controller.abort();
      params.signal?.addEventListener('abort', onParentAbort, { once: true });

      const startTime = Date.now();
      let timer: any = null;

      try {
        const timeoutPromise = new Promise<never>((_, reject) => {
          timer = setTimeout(() => {
            controller.abort();
            reject(new AppError('network', `Gemini call timed out after ${CALL_TIMEOUT_MS}ms`));
          }, CALL_TIMEOUT_MS);
        });

        // Determine thinking config: minimal for lite models, low for flash models
        const isLite = model.includes('lite');
        const thinkingConfig = {
          thinkingLevel: isLite ? ThinkingLevel.MINIMAL : ThinkingLevel.LOW,
        };

        const callPromise = ai.models.generateContent({
          model,
          contents: params.contents,
          config: {
            systemInstruction: params.systemInstruction,
            maxOutputTokens: currentMaxTokens,
            thinkingConfig,
            responseMimeType: 'application/json',
            abortSignal: controller.signal,
          },
        });

        const res = await Promise.race([callPromise, timeoutPromise]);
        clearTimeout(timer);
        params.signal?.removeEventListener('abort', onParentAbort);

        const duration = Date.now() - startTime;
        const candidate = res.candidates?.[0];
        const finishReason = candidate?.finishReason || 'STOP';
        const outputTokens = res.usageMetadata?.candidatesTokenCount || 0;
        const promptTokens = res.usageMetadata?.promptTokenCount || 0;

        // T0 log for attempt
        console.log(
          `[Gemini Attempt] pass="${params.passName}" model="${model}" duration=${duration}ms status=200 finishReason="${finishReason}" outputTokens=${outputTokens}`
        );

        params.tracker?.record({
          passName: params.passName,
          model,
          durationMs: duration,
          httpStatus: 200,
          finishReason,
          outputTokens,
          promptTokens,
        });

        // Check for MAX_TOKENS: shorten and retry once
        if (finishReason === 'MAX_TOKENS' && attempt === 0) {
          console.warn(`[Gemini Attempt] pass="${params.passName}" hit MAX_TOKENS. Shortening and retrying once...`);
          currentMaxTokens = Math.max(1024, Math.floor(currentMaxTokens * 0.7));
          attempt++;
          continue;
        }

        if (isLowerTier && params.tier === 'detail') {
          if (params.tracker) params.tracker.reducedDetail = true;
        }

        return {
          text: res.text || '',
          modelUsed: model,
          isReducedDetail: isLowerTier && params.tier === 'detail',
          finishReason,
          usageMetadata: res.usageMetadata,
        };
      } catch (err: any) {
        clearTimeout(timer);
        params.signal?.removeEventListener('abort', onParentAbort);

        const duration = Date.now() - startTime;
        const status = Number(err?.status || err?.statusCode || 500);
        const errMsg = String(err?.message || err);

        console.log(
          `[Gemini Attempt] pass="${params.passName}" model="${model}" duration=${duration}ms status=${status} error="${errMsg.slice(
            0,
            100
          )}"`
        );

        params.tracker?.record({
          passName: params.passName,
          model,
          durationMs: duration,
          httpStatus: status,
          error: errMsg,
        });

        lastError = err;

        if (params.signal?.aborted || errMsg.includes('cancelled')) {
          throw new AppError('cancelled');
        }

        // T1: exactly one retry per call
        // On 429: wait retryDelay (cap 20s), retry once
        if (status === 429 && attempt === 0) {
          attempt++;
          let delayMs = 2000;
          const match = errMsg.match(/retryDelay.*?"(\d+)s"/i) || errMsg.match(/retry.*?\s+(\d+)\s*s/i);
          if (match && match[1]) {
            delayMs = Math.min(MAX_RETRY_DELAY_MS, parseInt(match[1], 10) * 1000);
          }
          console.warn(`[Gemini Attempt] 429 received. Waiting ${delayMs}ms before single retry on ${model}...`);
          await sleep(delayMs, params.signal);
          continue;
        }

        if (status === 429 && attempt > 0) {
          if (errMsg.includes('per day limit exceeded') || errMsg.includes('PerDay')) {
            quotaExhaustedModels.add(model);
          }
        }

        // On timeout: retry once with lower maxOutputTokens
        const isTimeout = errMsg.includes('timed out') || errMsg.includes('timeout') || err?.code === 'network';
        if (isTimeout && attempt === 0) {
          attempt++;
          currentMaxTokens = Math.max(1024, Math.floor(currentMaxTokens * 0.7));
          console.warn(`[Gemini Attempt] Timeout on ${model}. Retrying once with lower tokens (${currentMaxTokens})...`);
          continue;
        }

        // Other non-retryable errors or already retried: break out to try fallback model if 404/503/429
        const isFallbackCandidate = status === 404 || status === 503 || status === 429 || status === 500;
        if (isFallbackCandidate) {
          console.warn(`[Gemini Attempt] Model ${model} failed (status ${status}). Trying next model...`);
          break; // break while loop to try next model in modelQueue
        }

        throw mapError(err);
      } finally {
        globalLimiter.release();
      }
    }
  }

  throw lastError ? mapError(lastError) : new AppError('network', 'All model attempts failed');
}

// ----------------------------------------------------------------------------
// T3: Pass A — Locate
// ----------------------------------------------------------------------------

export function validateBox(box: [number, number, number, number] | Box2D): Box2D | null {
  let ymin: number, xmin: number, ymax: number, xmax: number;
  if (Array.isArray(box)) {
    [ymin, xmin, ymax, xmax] = box;
  } else if (box && typeof box === 'object') {
    ({ ymin, xmin, ymax, xmax } = box);
  } else {
    return null;
  }

  if ([ymin, xmin, ymax, xmax].some((n) => typeof n !== 'number' || isNaN(n))) {
    return null;
  }

  // Inside 0-1000
  if (ymin < 0 || xmin < 0 || ymax > 1000 || xmax > 1000) {
    return null;
  }

  // ymax > ymin and xmax > xmin
  if (ymax <= ymin || xmax <= xmin) {
    return null;
  }

  // Minimum area: (ymax - ymin) * (xmax - xmin) >= 100
  const area = (ymax - ymin) * (xmax - xmin);
  if (area < 100) {
    return null;
  }

  return { ymin, xmin, ymax, xmax };
}

export async function directAiLocate(
  images: { base64: string; mimeType?: string }[],
  signal?: AbortSignal,
  tracker?: RunMetricsTracker
): Promise<LocateElement[]> {
  const parts: any[] = [];
  images.forEach((img, idx) => {
    const mimeType = img.mimeType || (img.base64.startsWith('/9j/') ? 'image/jpeg' : 'image/png');
    parts.push({
      text: `Locate every UI element in IMAGE_${idx + 1}: navigation links, buttons, headings, cards, tags, and props.`,
    });
    parts.push({
      inlineData: {
        mimeType,
        data: img.base64,
      },
    });
  });

  const res = await callGeminiWithPolicy({
    passName: 'Pass A (locate)',
    tier: 'detail',
    contents: [{ role: 'user', parts }],
    systemInstruction: LOCATE_PROMPT,
    maxOutputTokens: LOCATE_MAX_OUTPUT_TOKENS,
    signal,
    tracker,
  });

  const cleaned = cleanJsonResponse(res.text);
  let parsed: any = {};
  try {
    parsed = JSON.parse(cleaned);
  } catch (e) {
    console.warn('Failed to parse locate response JSON:', e);
    return [];
  }

  const rawElements: any[] = Array.isArray(parsed.elements) ? parsed.elements : [];
  const validElements: LocateElement[] = [];

  for (let i = 0; i < rawElements.length && validElements.length < 40; i++) {
    const el = rawElements[i];
    const b = el.box_2d || el.box;
    const validatedBox = validateBox(b);
    if (!validatedBox) continue;

    validElements.push({
      id: el.id || `el-${validElements.length + 1}`,
      kind: el.kind || 'container',
      label: el.label || 'unknown',
      box_2d: [validatedBox.ymin, validatedBox.xmin, validatedBox.ymax, validatedBox.xmax],
      text: el.text || null,
    });
  }

  return validElements;
}

// ----------------------------------------------------------------------------
// T3: Pass B — Regions (Zoom)
// ----------------------------------------------------------------------------

export async function directAiZoomRegion(
  regionImageBase64: string,
  regionMeasurements: any,
  signal?: AbortSignal,
  tracker?: RunMetricsTracker
): Promise<RegionInspection> {
  const mimeType = regionImageBase64.startsWith('/9j/') ? 'image/jpeg' : 'image/png';
  const parts = [
    { text: 'Inspect this regional section of the interface design. Extract all visible texts verbatim, card containers, characters, props, and typography.' },
    { inlineData: { mimeType, data: regionImageBase64 } },
    {
      text: `MEASURED PALETTE IN THIS REGION:\n${JSON.stringify(regionMeasurements || {}, null, 2)}`,
    },
  ];

  const res = await callGeminiWithPolicy({
    passName: 'Pass B (region zoom)',
    tier: 'detail',
    contents: [{ role: 'user', parts }],
    systemInstruction: REGION_PROMPT,
    maxOutputTokens: REGION_MAX_OUTPUT_TOKENS,
    signal,
    tracker,
  });

  const cleaned = cleanJsonResponse(res.text);
  try {
    return JSON.parse(cleaned) as RegionInspection;
  } catch (e) {
    console.warn('Failed to parse region zoom response JSON:', e);
    return {};
  }
}

// ----------------------------------------------------------------------------
// T3: Pass C — Global
// ----------------------------------------------------------------------------

export async function directAiGlobal(
  image1024Base64: string,
  signal?: AbortSignal,
  tracker?: RunMetricsTracker
): Promise<GlobalInspection> {
  const mimeType = image1024Base64.startsWith('/9j/') ? 'image/jpeg' : 'image/png';
  const parts = [
    { text: 'Inspect the full interface screenshot to extract global styling, theme, typography, spacing, and design rules.' },
    { inlineData: { mimeType, data: image1024Base64 } },
  ];

  const res = await callGeminiWithPolicy({
    passName: 'Pass C (global)',
    tier: 'lite', // Lite tier allowed for cheap global pass
    contents: [{ role: 'user', parts }],
    systemInstruction: GLOBAL_PROMPT,
    maxOutputTokens: GLOBAL_MAX_OUTPUT_TOKENS,
    signal,
    tracker,
  });

  const cleaned = cleanJsonResponse(res.text);
  try {
    return JSON.parse(cleaned) as GlobalInspection;
  } catch (e) {
    console.warn('Failed to parse global response JSON:', e);
    return {};
  }
}

// ----------------------------------------------------------------------------
// Analyze Website Entry Point
// ----------------------------------------------------------------------------

export async function directAiAnalyze(
  images: { base64: string; mimeType?: string }[],
  signal?: AbortSignal,
  tracker?: RunMetricsTracker
): Promise<AnalyzeResult> {
  const parts: any[] = [];
  images.forEach((img, idx) => {
    parts.push({ text: `IMAGE_${idx + 1}` });
    parts.push({
      inlineData: {
        mimeType: img.mimeType || 'image/png',
        data: img.base64,
      },
    });
  });

  const res = await callGeminiWithPolicy({
    passName: 'Analyze',
    tier: 'analyze',
    contents: [{ role: 'user', parts }],
    systemInstruction: ANALYZE_PROMPT,
    maxOutputTokens: ANALYZE_MAX_OUTPUT_TOKENS,
    signal,
    tracker,
  });

  const cleaned = cleanJsonResponse(res.text);
  let parsed: any;
  try {
    parsed = JSON.parse(cleaned);
  } catch (err: any) {
    throw new AppError('unreadable', `Analyze response was not valid JSON: ${err?.message}`);
  }

  if (parsed.isWebsite && (!parsed.sites || parsed.sites.length === 0)) {
    parsed.sites = [
      {
        id: 'site-1',
        label: 'unknown',
        description: 'unknown',
        sections: [],
        imageIndices: images.map((_, i) => i),
      },
    ];
  }

  const validated = validateAnalyzeResult(parsed);
  if (!validated.success || !validated.data) {
    throw new AppError('unreadable', `Analyze schema error: ${validated.errors?.join(', ')}`);
  }

  return validated.data;
}

// ----------------------------------------------------------------------------
// Universal Client/Server Callers (Client does NOT re-POST on timeout)
// ----------------------------------------------------------------------------

async function clientFetchWithTimeout<T>(
  url: string,
  body: any,
  signal?: AbortSignal
): Promise<T> {
  const controller = new AbortController();
  const onSignalAbort = () => controller.abort();
  signal?.addEventListener('abort', onSignalAbort, { once: true });

  let timer: any = null;
  const timeoutPromise = new Promise<never>((_, reject) => {
    timer = setTimeout(() => {
      controller.abort();
      reject(new AppError('network', `Client request timed out after ${CLIENT_CALL_TIMEOUT_MS}ms`));
    }, CLIENT_CALL_TIMEOUT_MS);
  });

  try {
    const fetchPromise = fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: controller.signal,
    }).then(async (resp) => {
      if (!resp.ok) {
        const errorJson = await resp.json().catch(() => ({}));
        const err = new AppError(
          errorJson.code || 'network',
          errorJson.message || `Server responded with ${resp.status}`
        );
        (err as any).status = errorJson.status || resp.status;
        throw err;
      }
      return resp.json() as Promise<T>;
    });

    return await Promise.race([fetchPromise, timeoutPromise]);
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener('abort', onSignalAbort);
  }
}

export async function callAiLocate(
  images: { base64: string; mimeType?: string }[],
  signal?: AbortSignal
): Promise<LocateElement[]> {
  if (typeof window !== 'undefined') {
    return clientFetchWithTimeout<LocateElement[]>('/api/ai/locate', { images }, signal);
  }
  return directAiLocate(images, signal);
}

export async function callAiZoomRegion(
  regionImageBase64: string,
  measurements: any,
  signal?: AbortSignal
): Promise<RegionInspection> {
  if (typeof window !== 'undefined') {
    return clientFetchWithTimeout<RegionInspection>(
      '/api/ai/zoom',
      { imageBase64: regionImageBase64, measurements },
      signal
    );
  }
  return directAiZoomRegion(regionImageBase64, measurements, signal);
}

export async function callAiGlobal(
  image1024Base64: string,
  signal?: AbortSignal
): Promise<GlobalInspection> {
  if (typeof window !== 'undefined') {
    return clientFetchWithTimeout<GlobalInspection>(
      '/api/ai/global',
      { image1024Base64 },
      signal
    );
  }
  return directAiGlobal(image1024Base64, signal);
}

export async function callAiAnalyze(
  images: { base64: string; mimeType?: string }[],
  signal?: AbortSignal
): Promise<AnalyzeResult> {
  if (typeof window !== 'undefined') {
    return clientFetchWithTimeout<AnalyzeResult>('/api/ai/analyze', { images }, signal);
  }
  return directAiAnalyze(images, signal);
}

export async function directAiExtract(
  images: { base64: string; mimeType?: string }[],
  measurements: Measurements,
  signal?: AbortSignal,
  tracker?: RunMetricsTracker
): Promise<DesignSpec> {
  const { assembleDesignSpec, groupBoxesIntoRegions } = await import('./assemble');
  const localTracker = tracker || new RunMetricsTracker();
  const primaryImg = images[0];

  // 1. Pass A: Locate
  const locateElements = await directAiLocate(images, signal, localTracker);

  // 2. Pass C: Global
  const globalData = await directAiGlobal(primaryImg.base64, signal, localTracker);

  // 3. Pass B: Group locate boxes into at most 6 regions
  const detectedBoxes = locateElements.map((el) => {
    const [ymin, xmin, ymax, xmax] = el.box_2d;
    return { ymin, xmin, ymax, xmax };
  });

  const regionBoxes = groupBoxesIntoRegions(detectedBoxes);
  const regionsData: { box: Box2D; inspection: RegionInspection; measuredRegion?: any }[] = [];
  const unresolvedRegions: Box2D[] = [];
  const passBStartTime = Date.now();

  for (let i = 0; i < regionBoxes.length; i++) {
    // T6: Stop launching new region calls after 100s
    if (Date.now() - passBStartTime > 100000) {
      unresolvedRegions.push(regionBoxes[i]);
      continue;
    }

    const rBox = regionBoxes[i];
    const regionMeasurements =
      measurements.regions?.find(
        (r) => r.box.ymin === rBox.ymin && r.box.xmin === rBox.xmin
      ) || measurements.regions?.[i];

    try {
      const inspection = await directAiZoomRegion(
        primaryImg.base64,
        regionMeasurements || { palette: measurements.palette.slice(0, 6) },
        signal,
        localTracker
      );
      regionsData.push({ box: rBox, inspection, measuredRegion: regionMeasurements });
    } catch (err) {
      console.warn(`[Pass B] Region ${i + 1} inspection failed, marking unresolved:`, err);
      unresolvedRegions.push(rBox);
    }
  }

  // Frame dimensions
  const cropW = measurements.cropRect?.width || measurements.dimensions?.[0]?.width || 1440;
  const cropH = measurements.cropRect?.height || measurements.dimensions?.[0]?.height || 1440;

  const spec = assembleDesignSpec({
    globalData,
    locateElements,
    regionsData,
    measurements,
    frameDimensions: { cropW, cropH },
    isReducedDetail: localTracker.reducedDetail,
    unresolvedRegions,
  });

  localTracker.printSummary();
  return spec;
}

export async function callAiExtract(
  images: { base64: string; mimeType?: string }[],
  measurements: Measurements,
  signal?: AbortSignal,
  onRetry?: (inSeconds: number, attempt: number) => void
): Promise<DesignSpec> {
  if (typeof window !== 'undefined') {
    return clientFetchWithTimeout<DesignSpec>(
      '/api/ai/extract',
      { images, measurements },
      signal
    );
  }
  return directAiExtract(images, measurements, signal);
}
