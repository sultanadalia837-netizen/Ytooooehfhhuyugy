/**
 * Pixel-accurate image palette, region, and background measurement
 * Document 2, Section 5.1 & Visual Reproduction Specification T3
 */

import { Box2D, MeasuredBackground, MeasuredColor, MeasuredRegion, Measurements } from '../types';
import { detectFrameCrop, cropPixelBuffer, PixelBuffer } from './frame';

export interface ImageInput {
  width: number;
  height: number;
  dataUrl: string;
}

function hexFromRgb(r: number, g: number, b: number): string {
  const toHex = (n: number) =>
    Math.max(0, Math.min(255, Math.round(n)))
      .toString(16)
      .padStart(2, '0')
      .toUpperCase();
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

function colorDistance(r1: number, g1: number, b1: number, r2: number, g2: number, b2: number): number {
  return Math.sqrt((r1 - r2) ** 2 + (g1 - g2) ** 2 + (b1 - b2) ** 2);
}

function computeMedian(arr: number[]): number {
  if (arr.length === 0) return 0;
  const sorted = [...arr].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0 ? sorted[mid] : Math.round((sorted[mid - 1] + sorted[mid]) / 2);
}

function computeMedianRgb(pixels: { r: number; g: number; b: number }[]): [number, number, number] {
  if (pixels.length === 0) return [0, 0, 0];
  const rList = pixels.map((p) => p.r);
  const gList = pixels.map((p) => p.g);
  const bList = pixels.map((p) => p.b);
  return [computeMedian(rList), computeMedian(gList), computeMedian(bList)];
}

function getChroma(r: number, g: number, b: number): number {
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  return (max - min) / 255;
}

/**
 * Extracts raw pixel buffer from an HTMLCanvasElement or Image dataUrl.
 * Caps the longest side at 1600 px while strictly maintaining aspect ratio.
 */
export async function loadPixelBuffer(img: ImageInput, maxSide = 1600): Promise<{ buffer: PixelBuffer; croppedDataUrl?: string; cropRect?: { x: number; y: number; width: number; height: number } }> {
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    // Node environment fallback (e.g., tests without DOM)
    const side = Math.min(img.width, img.height) || 100;
    return {
      buffer: {
        width: img.width || side,
        height: img.height || side,
        data: new Uint8ClampedArray((img.width || side) * (img.height || side) * 4),
      },
    };
  }

  return new Promise((resolve) => {
    const el = new Image();
    el.crossOrigin = 'anonymous';
    el.onload = () => {
      let w = el.naturalWidth || img.width;
      let h = el.naturalHeight || img.height;

      // Scale to maxSide if needed, preserving exact aspect ratio
      if (w > maxSide || h > maxSide) {
        if (w >= h) {
          h = Math.round((h * maxSide) / w);
          w = maxSide;
        } else {
          w = Math.round((w * maxSide) / h);
          h = maxSide;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d', { colorSpace: 'srgb' });
      if (!ctx) {
        resolve({
          buffer: { width: w, height: h, data: new Uint8ClampedArray(w * h * 4) },
        });
        return;
      }

      ctx.drawImage(el, 0, 0, w, h);
      const imgData = ctx.getImageData(0, 0, w, h);
      const rawBuffer: PixelBuffer = { width: w, height: h, data: imgData.data };

      // Detect uniform border / presentation mat
      const cropResult = detectFrameCrop(rawBuffer);
      let finalBuffer = rawBuffer;
      let croppedDataUrl = img.dataUrl;

      if (cropResult.hasBorder && cropResult.width > 40 && cropResult.height > 40) {
        finalBuffer = cropPixelBuffer(rawBuffer, cropResult);
        const cropCanvas = document.createElement('canvas');
        cropCanvas.width = cropResult.width;
        cropCanvas.height = cropResult.height;
        const cropCtx = cropCanvas.getContext('2d', { colorSpace: 'srgb' });
        if (cropCtx) {
          const croppedImgData = new ImageData(
            new Uint8ClampedArray(finalBuffer.data),
            finalBuffer.width,
            finalBuffer.height
          );
          cropCtx.putImageData(croppedImgData, 0, 0);
          croppedDataUrl = cropCanvas.toDataURL('image/png');
        }
      }

      resolve({
        buffer: finalBuffer,
        croppedDataUrl,
        cropRect: cropResult.hasBorder
          ? { x: cropResult.x, y: cropResult.y, width: cropResult.width, height: cropResult.height }
          : undefined,
      });
    };
    el.onerror = () => {
      resolve({
        buffer: { width: 100, height: 100, data: new Uint8ClampedArray(100 * 100 * 4) },
      });
    };
    el.src = img.dataUrl;
  });
}

/**
 * Measures the background properties: floor color, uniformity, lift, noise level
 */
export function measureBackground(buffer: PixelBuffer): MeasuredBackground {
  const { width, height, data } = buffer;

  const sample = (x: number, y: number): { r: number; g: number; b: number; hex: string } => {
    const clampedX = Math.max(0, Math.min(width - 1, Math.round(x)));
    const clampedY = Math.max(0, Math.min(height - 1, Math.round(y)));
    const idx = (clampedY * width + clampedX) * 4;
    const r = data[idx];
    const g = data[idx + 1];
    const b = data[idx + 2];
    return { r, g, b, hex: hexFromRgb(r, g, b) };
  };

  const corners = [
    sample(4, 4),
    sample(width - 5, 4),
    sample(4, height - 5),
    sample(width - 5, height - 5),
  ];

  const edges = [
    sample(width / 2, 4),
    sample(width / 2, height - 5),
    sample(4, height / 2),
    sample(width - 5, height / 2),
  ];

  const center = sample(width / 2, height / 2);

  // Determine floor color: median of edge and corner samples
  const allOuter = [...corners, ...edges];
  const [floorR, floorG, floorB] = computeMedianRgb(allOuter);
  const floorColor = hexFromRgb(floorR, floorG, floorB);

  // Check uniformity: all corners and edges within distance 20 of floor
  const isUniform = allOuter.every(
    (s) => colorDistance(s.r, s.g, s.b, floorR, floorG, floorB) < 20
  );

  // Check top lift
  let topLiftHex: string | undefined;
  let topLiftFadePercent: number | undefined;
  const topCenter = edges[0];
  if (colorDistance(topCenter.r, topCenter.g, topCenter.b, floorR, floorG, floorB) > 22) {
    topLiftHex = topCenter.hex;
    // Scan down from topCenter to find where it fades to floor color
    for (let y = 0; y < height; y += 4) {
      const s = sample(width / 2, y);
      if (colorDistance(s.r, s.g, s.b, floorR, floorG, floorB) < 15) {
        topLiftFadePercent = Math.round((y / height) * 100);
        break;
      }
    }
  }

  // Calculate noise level in a patch around top-left
  const patchPixels: number[] = [];
  const patchSize = Math.min(24, Math.floor(width / 4), Math.floor(height / 4));
  for (let y = 2; y < patchSize; y++) {
    for (let x = 2; x < patchSize; x++) {
      const idx = (y * width + x) * 4;
      const lum = 0.299 * data[idx] + 0.587 * data[idx + 1] + 0.114 * data[idx + 2];
      patchPixels.push(lum);
    }
  }

  const patchMean = patchPixels.reduce((a, b) => a + b, 0) / (patchPixels.length || 1);
  const variance =
    patchPixels.reduce((sum, val) => sum + (val - patchMean) ** 2, 0) / (patchPixels.length || 1);
  const noiseLevel = parseFloat(Math.sqrt(variance).toFixed(2));

  return {
    floorColor,
    isUniform,
    edgeSamples: edges.map((e) => e.hex),
    cornerSamples: corners.map((c) => c.hex),
    centerSample: center.hex,
    topLiftHex,
    topLiftFadePercent,
    noiseLevel,
  };
}

/**
 * Measures median top/middle/bottom colors and foreground color in a region box [ymin, xmin, ymax, xmax] (0-1000).
 */
export function measureRegion(buffer: PixelBuffer, box: Box2D): MeasuredRegion {
  const { width, height, data } = buffer;

  const xmin = Math.max(0, Math.min(width - 1, Math.round((box.xmin * width) / 1000)));
  const xmax = Math.max(xmin + 1, Math.min(width, Math.round((box.xmax * width) / 1000)));
  const ymin = Math.max(0, Math.min(height - 1, Math.round((box.ymin * height) / 1000)));
  const ymax = Math.max(ymin + 1, Math.min(height, Math.round((box.ymax * height) / 1000)));

  const h = ymax - ymin;
  const topCut = ymin + Math.floor(h / 3);
  const botCut = ymin + Math.floor((2 * h) / 3);

  const topPixels: { r: number; g: number; b: number }[] = [];
  const midPixels: { r: number; g: number; b: number }[] = [];
  const botPixels: { r: number; g: number; b: number }[] = [];
  const allPixels: { r: number; g: number; b: number }[] = [];

  for (let y = ymin; y < ymax; y++) {
    for (let x = xmin; x < xmax; x++) {
      const idx = (y * width + x) * 4;
      if (data[idx + 3] < 128) continue;
      const pixel = { r: data[idx], g: data[idx + 1], b: data[idx + 2] };
      allPixels.push(pixel);
      if (y < topCut) topPixels.push(pixel);
      else if (y < botCut) midPixels.push(pixel);
      else botPixels.push(pixel);
    }
  }

  const [topR, topG, topB] = computeMedianRgb(topPixels.length ? topPixels : allPixels);
  const [midR, midG, midB] = computeMedianRgb(midPixels.length ? midPixels : allPixels);
  const [botR, botG, botB] = computeMedianRgb(botPixels.length ? botPixels : allPixels);

  // Background approximation is median of all pixels
  const [bgR, bgG, bgB] = computeMedianRgb(allPixels);

  // For foreground: find top 10% highest contrast pixels relative to background
  const scoredPixels = allPixels.map((p) => ({
    ...p,
    contrast: colorDistance(p.r, p.g, p.b, bgR, bgG, bgB),
  }));

  scoredPixels.sort((a, b) => b.contrast - a.contrast);
  const top10PercentCount = Math.max(1, Math.floor(scoredPixels.length * 0.1));
  const fgPixels = scoredPixels.slice(0, top10PercentCount);
  const [fgR, fgG, fgB] = computeMedianRgb(fgPixels);

  return {
    box,
    topColor: hexFromRgb(topR, topG, topB),
    middleColor: hexFromRgb(midR, midG, midB),
    bottomColor: hexFromRgb(botR, botG, botB),
    foregroundColor: hexFromRgb(fgR, fgG, fgB),
  };
}

/**
 * Measures the full pixel buffer palette:
 * - Coarse clustering bins (16 bins per channel: step of 16)
 * - Exact median RGB for every cluster (NO loss of true values like #111111)
 * - Ranked by area * (1 + 3 * chroma) with minimum-count floor
 * - Returns up to 24 colors with no index-based roles
 */
export function measurePixels(buffer: PixelBuffer): { palette: MeasuredColor[]; background: MeasuredBackground } {
  const { width, height, data } = buffer;
  const totalPixels = width * height;

  // Key: coarse bin identifier "rBin:gBin:bBin" (step of 16)
  // Value: array of exact RGB pixels belonging to this cluster
  const clusters = new Map<string, { r: number; g: number; b: number }[]>();
  let sampledCount = 0;

  for (let i = 0; i < totalPixels; i++) {
    const idx = i * 4;
    const a = data[idx + 3];
    if (a < 128) continue;

    const r = data[idx];
    const g = data[idx + 1];
    const b = data[idx + 2];

    const rBin = Math.floor(r / 16);
    const gBin = Math.floor(g / 16);
    const bBin = Math.floor(b / 16);
    const key = `${rBin}:${gBin}:${bBin}`;

    let cluster = clusters.get(key);
    if (!cluster) {
      cluster = [];
      clusters.set(key, cluster);
    }
    cluster.push({ r, g, b });
    sampledCount++;
  }

  // Minimum count floor: at least 0.4% of sampled pixels or 8 pixels
  const minFloor = Math.max(8, Math.floor(sampledCount * 0.004));

  const measuredList: MeasuredColor[] = [];

  for (const [, pixels] of clusters.entries()) {
    if (pixels.length < minFloor) continue;

    const [medR, medG, medB] = computeMedianRgb(pixels);
    const hex = hexFromRgb(medR, medG, medB);
    const chroma = getChroma(medR, medG, medB);
    const area = pixels.length / (sampledCount || 1);
    const score = area * (1 + 3 * chroma);

    measuredList.push({
      hex,
      medianRgb: [medR, medG, medB],
      percentage: parseFloat((area * 100).toFixed(2)),
      chroma: parseFloat(chroma.toFixed(3)),
      score: parseFloat(score.toFixed(4)),
      pixelCount: pixels.length,
    });
  }

  // Merge clusters that resolved to virtually identical median colors (distance < 16)
  const merged: MeasuredColor[] = [];
  measuredList.sort((a, b) => b.score! - a.score!);

  for (const item of measuredList) {
    const [r, g, b] = item.medianRgb!;
    let matched = false;

    for (const existing of merged) {
      const [exR, exG, exB] = existing.medianRgb!;
      if (colorDistance(r, g, b, exR, exG, exB) < 16) {
        existing.percentage = parseFloat(((existing.percentage || 0) + (item.percentage || 0)).toFixed(2));
        existing.pixelCount = (existing.pixelCount || 0) + (item.pixelCount || 0);
        existing.score = parseFloat(((existing.score || 0) + (item.score || 0)).toFixed(4));
        matched = true;
        break;
      }
    }

    if (!matched) {
      merged.push({ ...item });
    }
  }

  // Sort by score descending and return up to 24 colors
  const top24 = merged.sort((a, b) => b.score! - a.score!).slice(0, 24);

  const background = measureBackground(buffer);

  return {
    palette: top24,
    background,
  };
}

/**
 * Main entry point for measuring uploaded images
 */
export async function measureImages(
  images: ImageInput[],
  regionsToMeasure: Box2D[] = []
): Promise<Measurements> {
  const dimensions = images.map((img) => ({
    width: img.width,
    height: img.height,
    aspectRatio: img.height > 0 ? parseFloat((img.width / img.height).toFixed(3)) : 1,
  }));

  if (images.length === 0) {
    return { palette: [], dimensions: [] };
  }

  // Work on the primary image
  const first = images[0];
  const { buffer, cropRect } = await loadPixelBuffer(first, 1600);
  const { palette, background } = measurePixels(buffer);

  // Measure requested regions if any
  const measuredRegions: MeasuredRegion[] = regionsToMeasure.map((box) =>
    measureRegion(buffer, box)
  );

  return {
    palette,
    dimensions,
    background,
    regions: measuredRegions,
    cropRect,
  };
}

export function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace('#', '').trim();
  if (clean.length === 3) {
    return [
      parseInt(clean[0] + clean[0], 16) || 0,
      parseInt(clean[1] + clean[1], 16) || 0,
      parseInt(clean[2] + clean[2], 16) || 0,
    ];
  }
  return [
    parseInt(clean.substring(0, 2), 16) || 0,
    parseInt(clean.substring(2, 4), 16) || 0,
    parseInt(clean.substring(4, 6), 16) || 0,
  ];
}

export function rgbToLab(r: number, g: number, b: number): [number, number, number] {
  let lr = r / 255;
  let lg = g / 255;
  let lb = b / 255;

  lr = lr > 0.04045 ? Math.pow((lr + 0.055) / 1.055, 2.4) : lr / 12.92;
  lg = lg > 0.04045 ? Math.pow((lg + 0.055) / 1.055, 2.4) : lg / 12.92;
  lb = lb > 0.04045 ? Math.pow((lb + 0.055) / 1.055, 2.4) : lb / 12.92;

  let x = lr * 0.4124 + lg * 0.3576 + lb * 0.1805;
  let y = lr * 0.2126 + lg * 0.7152 + lb * 0.0722;
  let z = lr * 0.0193 + lg * 0.1192 + lb * 0.9505;

  x /= 0.95047;
  y /= 1.0;
  z /= 1.08883;

  x = x > 0.008856 ? Math.pow(x, 1 / 3) : 7.787 * x + 16 / 116;
  y = y > 0.008856 ? Math.pow(y, 1 / 3) : 7.787 * y + 16 / 116;
  z = z > 0.008856 ? Math.pow(z, 1 / 3) : 7.787 * z + 16 / 116;

  return [116 * y - 16, 500 * (x - y), 200 * (y - z)];
}

export function deltaE(hex1: string, hex2: string): number {
  if (!hex1 || !hex2 || hex1 === 'unknown' || hex2 === 'unknown') return 999;
  const [r1, g1, b1] = hexToRgb(hex1);
  const [r2, g2, b2] = hexToRgb(hex2);
  const [L1, a1, b1_val] = rgbToLab(r1, g1, b1);
  const [L2, a2, b2_val] = rgbToLab(r2, g2, b2);
  return Math.sqrt((L1 - L2) ** 2 + (a1 - a2) ** 2 + (b1_val - b2_val) ** 2);
}

export function isMeasuredColorMatch(
  candidateHex: string,
  measuredPalette: { hex: string }[],
  maxDeltaE = 6
): boolean {
  if (!candidateHex || candidateHex === 'unknown') return false;
  return measuredPalette.some((m) => deltaE(candidateHex, m.hex) <= maxDeltaE);
}

export function assignColorSource(
  hex: string | undefined,
  measuredPalette: { hex: string }[],
  isDirectlySampled = false
): import('../types').ValueSource {
  if (!hex || hex === 'unknown' || hex === 'none') return 'unknown';
  if (isDirectlySampled) return 'measured';
  if (isMeasuredColorMatch(hex, measuredPalette, 6)) return 'measured';
  return 'estimated';
}

export function assignValueSource<T>(
  val: T,
  isDirectlyMeasured = false,
  isInferred = false
): import('../types').ValueSource {
  if (val === undefined || val === null || val === '' || val === 'unknown') {
    return 'unknown';
  }
  if (isDirectlyMeasured) return 'measured';
  if (isInferred) return 'inferred';
  return 'estimated';
}
