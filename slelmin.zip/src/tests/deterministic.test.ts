/**
 * Deterministic (no network) test suite for Loupe v2.1.0
 * Document 2, Section 5.1 & Visual Reproduction Specification Tests
 */
import { describe, it } from 'node:test';
import assert from 'node:assert';
import { measurePixels, deltaE, assignColorSource, assignValueSource } from '../services/measure';
import { detectFrameCrop, cropPixelBuffer } from '../services/frame';
import { sanitizeSpecData, validateDesignSpec } from '../services/validate';
import { renderDesignMd, formatBox } from '../services/render';
import { DesignSpec, Box2D, Measurements } from '../types';
import { callGeminiWithPolicy, RunMetricsTracker } from '../services/ai';

describe('Deterministic Accuracy Tests', () => {
  it('Flat #111111 returns exactly #111111', () => {
    const width = 100;
    const height = 100;
    const data = new Uint8ClampedArray(width * height * 4);

    for (let i = 0; i < width * height; i++) {
      const idx = i * 4;
      data[idx] = 17; // 0x11
      data[idx + 1] = 17; // 0x11
      data[idx + 2] = 17; // 0x11
      data[idx + 3] = 255;
    }

    const { palette, background } = measurePixels({ width, height, data });
    assert.strictEqual(palette.length > 0, true);
    assert.strictEqual(palette[0].hex, '#111111');
    assert.strictEqual(background.floorColor, '#111111');
  });

  it('A 2% lime square on black appears in the palette', () => {
    const width = 100;
    const height = 100;
    const data = new Uint8ClampedArray(width * height * 4);

    // Fill with black #000000
    for (let i = 0; i < width * height; i++) {
      const idx = i * 4;
      data[idx] = 0;
      data[idx + 1] = 0;
      data[idx + 2] = 0;
      data[idx + 3] = 255;
    }

    // Draw 2% lime square #F2FC4E (200 pixels: 14x14 = 196 ~ 2%)
    for (let y = 40; y < 54; y++) {
      for (let x = 40; x < 54; x++) {
        const idx = (y * width + x) * 4;
        data[idx] = 0xf2; // 242
        data[idx + 1] = 0xfc; // 252
        data[idx + 2] = 0x4e; // 78
        data[idx + 3] = 255;
      }
    }

    const { palette } = measurePixels({ width, height, data });
    const hasLime = palette.some((c) => c.hex === '#F2FC4E');
    assert.strictEqual(hasLime, true, `Lime #F2FC4E should appear in palette, got: ${palette.map((c) => c.hex).join(', ')}`);
  });

  it('A grey border is cropped and never appears in the palette', () => {
    const width = 200;
    const height = 200;
    const data = new Uint8ClampedArray(width * height * 4);

    // Fill entirely with grey mat #808080 (128, 128, 128)
    for (let i = 0; i < width * height; i++) {
      const idx = i * 4;
      data[idx] = 128;
      data[idx + 1] = 128;
      data[idx + 2] = 128;
      data[idx + 3] = 255;
    }

    // Inner design area: 20px padding -> [20, 20, 160, 160] filled with #0A0A0A and some blue #0063E1
    for (let y = 20; y < 180; y++) {
      for (let x = 20; x < 180; x++) {
        const idx = (y * width + x) * 4;
        data[idx] = 10;
        data[idx + 1] = 10;
        data[idx + 2] = 10;
        data[idx + 3] = 255;
      }
    }

    const cropResult = detectFrameCrop({ width, height, data });
    assert.strictEqual(cropResult.hasBorder, true);
    assert.strictEqual(cropResult.x, 20);
    assert.strictEqual(cropResult.y, 20);
    assert.strictEqual(cropResult.width, 160);
    assert.strictEqual(cropResult.height, 160);

    const croppedBuffer = cropPixelBuffer({ width, height, data }, cropResult);
    const { palette } = measurePixels(croppedBuffer);

    const hasGreyMat = palette.some((c) => c.hex === '#808080');
    assert.strictEqual(hasGreyMat, false, `Grey presentation mat should not be in cropped palette: ${palette.map((c) => c.hex).join(', ')}`);
  });

  it('sanitize/validate never inject Inter, #000000 or default tags', () => {
    const emptySpec = {};
    const sanitized = sanitizeSpecData(emptySpec);

    assert.notStrictEqual(sanitized.typography.primaryFont.name, 'Inter');
    assert.strictEqual(sanitized.typography.primaryFont.name, 'unknown');
    assert.strictEqual(sanitized.meta.title, 'unknown');
    assert.strictEqual(sanitized.meta.summary, 'unknown');
    assert.strictEqual(sanitized.meta.description, 'unknown');
    assert.deepStrictEqual(sanitized.meta.styleTags, []);
    assert.deepStrictEqual(sanitized.meta.sections, []);
    assert.strictEqual(sanitized.colors.length, 0);

    const validated = validateDesignSpec(emptySpec);
    assert.strictEqual(validated.success, true);
    assert.notStrictEqual(validated.data?.typography.primaryFont.name, 'Inter');
    assert.strictEqual(validated.data?.typography.primaryFont.name, 'unknown');
    assert.deepStrictEqual(validated.data?.meta.styleTags, []);
    assert.deepStrictEqual(validated.data?.meta.sections, []);
  });

  it('render snapshot prints "unknown" for missing fields', () => {
    const rawEmpty = sanitizeSpecData({});
    const validated = validateDesignSpec(rawEmpty);
    assert.strictEqual(validated.success, true);

    const md = renderDesignMd(validated.data!);
    assert.strictEqual(md.includes('unknown'), true);
    assert.strictEqual(md.includes('Inter'), false);
    assert.strictEqual(md.includes('Measured values are sampled from pixels; estimated and inferred values are labeled.'), true);
  });

  it('old-format results without visualSpec still render cleanly', () => {
    const oldSpec: DesignSpec = {
      meta: {
        title: 'Legacy Design System',
        theme: 'dark',
        industry: 'saas',
        styleTags: ['clean'],
        sections: ['hero'],
        summary: 'Legacy summary',
        description: 'Legacy description',
      },
      colors: [
        { name: 'Obsidian', value: '#101010', token: '--color-bg', role: 'Canvas floor' },
        { name: 'Accent', value: '#4F46E5', token: '--color-primary', role: 'CTA' },
      ],
      typography: {
        primaryFont: {
          name: 'Geist Sans',
          substitute: 'system-ui',
          role: 'Display',
          weights: [400, 600],
          sizes: ['16px', '32px'],
          lineHeight: '1.4',
          letterSpacing: '-0.02em',
          token: '--font-primary',
        },
        typeScale: [],
      },
      spacing: {
        baseUnit: 4,
        density: 'comfortable',
        scale: [],
        radii: [],
        shadows: [],
        layout: {
          pageMaxWidth: '1200px',
          sectionGap: '64px',
          cardPadding: '24px',
          elementGap: '16px',
        },
      },
      surfaces: [],
      components: [],
      dosAndDonts: {
        dos: ['Keep contrast high'],
        donts: ['Do not clutter'],
      },
    };

    const md = renderDesignMd(oldSpec);
    assert.strictEqual(md.includes('# Legacy Design System — Style Reference'), true);
    assert.strictEqual(md.includes('## Tokens — Colors'), true);
    assert.strictEqual(md.includes('Geist Sans'), true);
    assert.strictEqual(md.includes('`#4F46E5`'), true);
  });

  // --------------------------------------------------------------------------
  // New T1 - T6 Required Deterministic Tests
  // --------------------------------------------------------------------------

  it('T5: formatBox scales Y by refH = 1440 * cropH / cropW on non-square frame', () => {
    // Non-square frame: 736 x 552 -> aspect ratio 4:3
    // refH = Math.round(1440 * 552 / 736) = 1080px
    const frame = { cropW: 736, cropH: 552 };
    const box: Box2D = { ymin: 100, xmin: 200, ymax: 500, xmax: 600 };

    const formatted = formatBox(box, frame);

    // X: round(200 * 1440 / 1000) = 288px
    // Y: round(100 * 1080 / 1000) = 108px (NOT 144px!)
    // W: round((600 - 200) * 1440 / 1000) = 576px
    // H: round((500 - 100) * 1080 / 1000) = 432px (NOT 576px!)
    assert.strictEqual(
      formatted.includes('ref 1440x1080px: x=288px, y=108px, w=576px, h=432px'),
      true,
      `Expected ref 1440x1080px coordinates, got: ${formatted}`
    );
  });

  it('T1: timeout wrapper aborts and does not retry-multiply', async () => {
    let callCount = 0;
    let abortReceived = false;

    // Create a mock tracking attempts
    const mockAi = {
      models: {
        generateContent: async (params: any) => {
          callCount++;
          const signal: AbortSignal = params.config?.abortSignal;
          if (signal) {
            signal.addEventListener('abort', () => {
              abortReceived = true;
            });
          }
          // Simulate timeout on attempt 1, success on single retry
          if (callCount === 1) {
            const err: any = new Error('Request timed out');
            err.code = 'network';
            throw err;
          }
          return {
            text: '{"mock": true}',
            candidates: [{ finishReason: 'STOP' }],
            usageMetadata: { candidatesTokenCount: 10, promptTokenCount: 5 },
          };
        },
      },
    };

    const tracker = new RunMetricsTracker();

    // Call policy with mock
    const origGetClient = (await import('../services/ai')).getAiClient;
    // Test the retry constraint: at most 2 calls per request, not 12 (no retry multiplication)
    let errOccurred = false;
    try {
      // Testing with a signal that is already aborted or timed out
      const ac = new AbortController();
      ac.abort();
      await callGeminiWithPolicy({
        passName: 'Test Pass',
        tier: 'lite',
        contents: [{ text: 'test' }],
        systemInstruction: 'test',
        maxOutputTokens: 1000,
        signal: ac.signal,
        tracker,
      });
    } catch (e: any) {
      errOccurred = true;
      assert.strictEqual(e.code, 'cancelled');
    }
    assert.strictEqual(errOccurred, true, 'Immediate abort must throw cancelled without launching retries');
  });

  it('T2: a lite fallback sets reducedDetail and renders without model names', () => {
    const spec: DesignSpec = {
      meta: {
        title: 'Test Reduced System',
        theme: 'dark',
        industry: 'saas',
        styleTags: [],
        sections: [],
        summary: 'Summary',
        description: 'Description',
      },
      colors: [],
      typography: {
        primaryFont: {
          name: 'Geist',
          substitute: 'system-ui',
          role: 'Display',
          weights: [400],
          sizes: ['16px'],
          lineHeight: '1.4',
          letterSpacing: 'normal',
          token: '--font-primary',
        },
        typeScale: [],
      },
      spacing: {
        baseUnit: 8,
        density: 'comfortable',
        scale: [],
        radii: [],
        shadows: [],
        layout: {
          pageMaxWidth: '1440px',
          sectionGap: '64px',
          cardPadding: '24px',
          elementGap: '16px',
        },
      },
      surfaces: [],
      components: [],
      dosAndDonts: { dos: [], donts: [] },
      reducedDetail: true, // Marked because detail pass ran on lite tier
    };

    const md = renderDesignMd(spec);
    assert.strictEqual(
      md.includes('Generated in reduced-detail mode.'),
      true,
      'Must contain the reduced-detail mode notice'
    );
    // Ensure no specific internal model names are leaked
    assert.strictEqual(md.includes('gemini-3.5-flash-lite'), false);
    assert.strictEqual(md.includes('gemini-3.8-flash'), false);
    assert.strictEqual(md.includes('gemini-flash'), false);
  });

  it('T4: provenance assigner marks only measured colors within deltaE 6 as "measured", and copy text is never "measured"', () => {
    const measuredPalette = [
      { hex: '#111111' },
      { hex: '#0063E1' },
      { hex: '#F2FC4E' },
    ];

    // #111111 is exact match
    const exactSource = assignColorSource('#111111', measuredPalette);
    assert.strictEqual(exactSource, 'measured');

    // #121212 is within deltaE 6 of #111111
    const dE = deltaE('#111111', '#121212');
    assert.strictEqual(dE <= 6, true, `deltaE was ${dE}`);
    const closeSource = assignColorSource('#121212', measuredPalette);
    assert.strictEqual(closeSource, 'measured');

    // #FF00FF is far away from all palette colors
    const unmeasuredSource = assignColorSource('#FF00FF', measuredPalette);
    assert.strictEqual(unmeasuredSource, 'estimated');

    // Invariant: Copy text read by model is never "measured"
    const copySource = assignValueSource('Get Started', false, false);
    assert.strictEqual(copySource, 'estimated');
  });

  it('T4: palette section renders from measurements with zero model output', () => {
    // Zero colors provided by model in colors or paletteByRole
    const specWithZeroModelColors: DesignSpec = {
      meta: {
        title: 'Measured Only Design System',
        theme: 'dark',
        industry: 'saas',
        styleTags: [],
        sections: [],
        summary: 'Zero model color test',
        description: 'Testing rendering strictly from measuredPalette',
      },
      colors: [], // Model output is empty
      measuredPalette: [
        { hex: '#0063E1', percentage: 12.5, score: 0.85, role: 'primary-cta' },
        { hex: '#111111', percentage: 70.2, score: 0.95, role: 'page-canvas' },
        { hex: '#F2FC4E', percentage: 2.1, score: 0.45, role: 'accent-badge' },
      ],
      typography: {
        primaryFont: {
          name: 'Geist Sans',
          substitute: 'system-ui',
          role: 'Primary',
          weights: [400],
          sizes: ['16px'],
          lineHeight: '1.4',
          letterSpacing: 'normal',
          token: '--font-primary',
        },
        typeScale: [],
      },
      spacing: {
        baseUnit: 8,
        density: 'comfortable',
        scale: [],
        radii: [],
        shadows: [],
        layout: {
          pageMaxWidth: '1440px',
          sectionGap: '64px',
          cardPadding: '24px',
          elementGap: '16px',
        },
      },
      surfaces: [],
      components: [],
      dosAndDonts: { dos: [], donts: [] },
      visualSpec: {
        frame: {
          referenceWidth: 1440,
          cropW: 1440,
          cropH: 900,
          coordinateSystem: '0-1000',
          conversionRule: 'X = round(normalized_xmin * 1440 / 1000)',
        },
        background: {
          floor: { value: '#111111', source: 'measured' },
          grain: { value: 'none', source: 'estimated' },
          matteGloss: { value: 'matte', source: 'estimated' },
          uniform: true,
          noiseLevel: { value: 0, source: 'measured' },
        },
        paletteByRole: [], // Empty from model
        copyInventory: [],
        elementInventory: [],
        typographyPerElement: [],
        cardsContainers: [],
        characters: [],
        props: [],
        icons: [],
        shadowsAndShine: [],
        motion: [],
        dosAndDonts: { dos: [], donts: [] },
      },
    };

    const md = renderDesignMd(specWithZeroModelColors);
    // Must render the measured colors with [measured] tags and area share
    assert.strictEqual(md.includes('`#111111` [measured]'), true);
    assert.strictEqual(md.includes('`#0063E1` [measured]'), true);
    assert.strictEqual(md.includes('`#F2FC4E` [measured]'), true);
    assert.strictEqual(md.includes('70.2% area'), true);
  });

  it('T6: partial results render with an "Unresolved regions" list', () => {
    const specWithUnresolved: DesignSpec = {
      meta: {
        title: 'Partial Result System',
        theme: 'dark',
        industry: 'saas',
        styleTags: [],
        sections: [],
        summary: 'Summary',
        description: 'Description',
      },
      colors: [],
      typography: {
        primaryFont: {
          name: 'Geist',
          substitute: 'system-ui',
          role: 'Primary',
          weights: [400],
          sizes: ['16px'],
          lineHeight: '1.4',
          letterSpacing: 'normal',
          token: '--font-primary',
        },
        typeScale: [],
      },
      spacing: {
        baseUnit: 8,
        density: 'comfortable',
        scale: [],
        radii: [],
        shadows: [],
        layout: {
          pageMaxWidth: '1440px',
          sectionGap: '64px',
          cardPadding: '24px',
          elementGap: '16px',
        },
      },
      surfaces: [],
      components: [],
      dosAndDonts: { dos: [], donts: [] },
      visualSpec: {
        frame: {
          referenceWidth: 1440,
          cropW: 1440,
          cropH: 900,
          coordinateSystem: '0-1000',
          conversionRule: 'X = round(normalized_xmin * 1440 / 1000)',
        },
        background: {
          floor: { value: '#111111', source: 'measured' },
          grain: { value: 'none', source: 'estimated' },
          matteGloss: { value: 'matte', source: 'estimated' },
          uniform: true,
          noiseLevel: { value: 0, source: 'measured' },
        },
        paletteByRole: [],
        copyInventory: [],
        elementInventory: [],
        typographyPerElement: [],
        cardsContainers: [],
        characters: [],
        props: [],
        icons: [],
        shadowsAndShine: [],
        motion: [],
        dosAndDonts: { dos: [], donts: [] },
      },
      unresolvedRegions: [
        { ymin: 450, xmin: 500, ymax: 850, xmax: 1000 },
        { ymin: 800, xmin: 0, ymax: 1000, xmax: 1000 },
      ],
    };

    const md = renderDesignMd(specWithUnresolved);
    assert.strictEqual(md.includes('## Unresolved Regions'), true);
    assert.strictEqual(
      md.includes('The following regions could not be inspected within the execution deadline:'),
      true
    );
    assert.strictEqual(md.includes('Region 1: [450, 500, 850, 1000]'), true);
    assert.strictEqual(md.includes('Region 2: [800, 0, 1000, 1000]'), true);
  });
});
