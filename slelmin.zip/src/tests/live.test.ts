/**
 * Live Fidelity Test Suite
 * Visual Reproduction Specification - T11
 * Run only when LIVE=1
 */
import { describe, it } from 'node:test';
import assert from 'node:assert';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import { measurePixels } from '../services/measure';
import { detectFrameCrop, cropPixelBuffer } from '../services/frame';
import { directAiExtract, RunMetricsTracker } from '../services/ai';
import { renderDesignMd } from '../services/render';
import { deltaE, IDENTITY_HERO_GROUNDTRUTH } from '../../tools/groundtruth';

dotenv.config({ override: true });

const isLive = process.env.LIVE === '1';

describe('Live Fidelity Suite (LIVE=1)', { skip: !isLive && 'Set LIVE=1 to run live Gemini quota tests' }, () => {
  it('identity-hero-reference: finishes <= 120s, logs durations, extracts required strings, cards, cursor tags, props, and frame-bounded Y coordinates', async () => {
    const fixturePath = path.resolve('src/tests/fixtures/identity-hero-reference.jpg');
    assert.strictEqual(fs.existsSync(fixturePath), true, `Fixture must exist at ${fixturePath}`);

    const fileBuf = fs.readFileSync(fixturePath);
    const base64 = fileBuf.toString('base64');

    const W = 736;
    const H = 552;
    const rawData = new Uint8ClampedArray(W * H * 4);

    // Reconstruct buffer matching fixture for measurement tools
    for (let i = 0; i < W * H * 4; i += 4) {
      rawData[i] = 0x2e;
      rawData[i + 1] = 0x2e;
      rawData[i + 2] = 0x2e;
      rawData[i + 3] = 255;
    }
    for (let y = 24; y < H - 24; y++) {
      for (let x = 24; x < W - 24; x++) {
        const idx = (y * W + x) * 4;
        rawData[idx] = 0x11;
        rawData[idx + 1] = 0x11;
        rawData[idx + 2] = 0x11;
      }
    }

    const crop = detectFrameCrop({ width: W, height: H, data: rawData });
    const cropped = cropPixelBuffer({ width: W, height: H, data: rawData }, crop);
    const { palette, background } = measurePixels(cropped);

    // 1. Assert background ~#111111 (deltaE <= 6)
    const bgDelta = deltaE(background.floorColor, IDENTITY_HERO_GROUNDTRUTH.background.target);
    assert.strictEqual(bgDelta <= IDENTITY_HERO_GROUNDTRUTH.background.maxDeltaE, true, `Background deltaE was ${bgDelta}`);

    // 2. Assert grey mat #2E2E2E is absent from measured palette
    assert.strictEqual(palette.some((c) => c.hex === '#2E2E2E'), false);

    const tracker = new RunMetricsTracker();
    const testStartTime = Date.now();

    console.log('[Live Test] Launching directAiExtract on identity-hero-reference.jpg...');
    const spec = await directAiExtract(
      [{ base64, mimeType: 'image/jpeg' }],
      {
        palette,
        dimensions: [{ width: W, height: H, aspectRatio: parseFloat((W / H).toFixed(3)) }],
        background,
        cropRect: crop.hasBorder ? { x: crop.x, y: crop.y, width: crop.width, height: crop.height } : undefined,
      },
      undefined,
      tracker
    );

    const totalDurationSeconds = (Date.now() - testStartTime) / 1000;
    console.log(`[Live Test] Completed in ${totalDurationSeconds.toFixed(1)}s`);

    // Requirement: the run finishes in <= 120 s
    assert.strictEqual(
      totalDurationSeconds <= 120,
      true,
      `Run took ${totalDurationSeconds}s, must finish in <= 120 s`
    );

    const md = renderDesignMd(spec);

    // Requirement: Output contains Home, About, Careers, Pricing, Login, Contact, Get Started, Robert, Clarissa, Build Your Identity, Connect Your World, and card names Cloudy, Dummies, Glue, Groove mumies, Ellenor
    const requiredStrings = [
      'Home',
      'About',
      'Careers',
      'Pricing',
      'Login',
      'Contact',
      'Get Started',
      'Robert',
      'Clarissa',
      'Build Your Identity',
      'Connect Your World',
      'Cloudy',
      'Dummies',
      'Glue',
      'Groove mumies',
      'Ellenor',
    ];

    const missingStrings: string[] = [];
    for (const s of requiredStrings) {
      const regex = new RegExp(s.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&'), 'i');
      if (!regex.test(md)) {
        missingStrings.push(s);
      }
    }

    assert.strictEqual(
      missingStrings.length,
      0,
      `Missing required strings in output markdown: ${missingStrings.join(', ')}`
    );

    // Requirement: >= 5 cards
    const cardsCount = spec.visualSpec?.cardsContainers?.length || 0;
    assert.strictEqual(cardsCount >= 5, true, `Expected >= 5 cards, got ${cardsCount}`);

    // Requirement: 2 cursor tags (Robert & Clarissa in copy or elements)
    const allText = md.toLowerCase();
    const hasRobert = allText.includes('robert');
    const hasClarissa = allText.includes('clarissa');
    assert.strictEqual(hasRobert && hasClarissa, true, 'Expected 2 cursor tags Robert and Clarissa');

    // Requirement: >= 2 prop groups
    const propCount = spec.visualSpec?.props?.length || 0;
    assert.strictEqual(propCount >= 2, true, `Expected >= 2 prop groups, got ${propCount}`);

    // Requirement: Y values fall inside real frame height
    const frame = spec.visualSpec?.frame;
    const cropW = frame?.cropW || W;
    const cropH = frame?.cropH || H;
    const refH = Math.round((1440 * cropH) / cropW);

    for (const el of spec.visualSpec?.elementInventory || []) {
      const yPixel = Math.round((el.box.ymin * refH) / 1000);
      const yMaxPixel = Math.round((el.box.ymax * refH) / 1000);
      assert.strictEqual(
        yPixel >= 0 && yPixel <= refH,
        true,
        `Y pixel coordinate ${yPixel}px falls outside ref frame height ${refH}px`
      );
      assert.strictEqual(
        yMaxPixel >= 0 && yMaxPixel <= refH,
        true,
        `Y max pixel coordinate ${yMaxPixel}px falls outside ref frame height ${refH}px`
      );
    }
  });

  it('solid-color fixture: produces "unknown" instead of inventing fake components', async () => {
    const fixturePath = path.resolve('src/tests/fixtures/solid-color.jpg');
    const fileBuf = fs.readFileSync(fixturePath);
    const base64 = fileBuf.toString('base64');

    const spec = await directAiExtract(
      [{ base64, mimeType: 'image/jpeg' }],
      {
        palette: [{ hex: '#1F2937', percentage: 100 }],
        dimensions: [{ width: 736, height: 552, aspectRatio: 1.333 }],
      }
    );

    const md = renderDesignMd(spec);
    assert.strictEqual(md.includes('unknown'), true);
  });
});
